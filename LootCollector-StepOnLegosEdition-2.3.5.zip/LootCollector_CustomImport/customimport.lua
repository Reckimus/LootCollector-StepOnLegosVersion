-- 4913c0:103726330c2d0f26242c30:42ab500f
-- Place long import string between ""
-- e998-XnlofUJjQWhqYn4-d0304137

-- 6a128329.486f7e6b5475577e7c7468.4254abe0

-- 36a997:bf98899ca382a0898b839f:cdc5e0cc
_G.LootCollector_CustiomImport = ""