-- 2bcc1c:280f1e0b3415371e1c1408:87740467
-- Interoperability with the LCR1 records used by the supplied CoA fork.
local L=LootCollector
local P=L:GetModule("POI")
local B=L:NewModule("POICompat","AceEvent-3.0","AceComm-3.0")
local S=LibStub("AceSerializer-3.0")
local D=LibStub("LibDeflate")
B.peers,B.requested,B.jobs,B.rates={},{},{},{}
local function text(s,max)
    if type(s)~="string" then return nil end
    s=s:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("[%c|]"," "):gsub("%s+"," "):match("^%s*(.-)%s*$")
    if s=="" then return nil end
    return s:sub(1,max or 96)
end
local function norm(s)return L:normalizeSenderName(s or "")end
local function realm()return L:GetActiveRealmKey()end
local function allowed(sender,via)return P:CanReceive(sender,via)end
local function canSend()
    local c=L:GetModule("Comm",true)
    local p=L.db and L.db.profile
    return p and p.sharing.enabled and not L:IsPaused() and not L:IsZoneIgnored()
        and (not p.poi or (p.poi.enabled~=false and p.poi.share~=false)) and c and c:CanSendPOI()
end
function B:Continent(rec)
    local z=tonumber(rec.map)
    local zones=L:GetModule("ZoneList",true)
    local info=zones and zones.MapDataByID and zones.MapDataByID[z]
    if info and tonumber(info.continentID) then return tonumber(info.continentID) end
    local c=tonumber(rec.c)
    if c and c>=1 and c<=4 then return c end
    if z==GetCurrentMapAreaID() then return GetCurrentMapContinent() end
end
function B:FromLegacy(rec,sender,localImport)
    if type(rec)~="table" then return end
    local kinds={rare="RARE",chest="CHEST",highrisk="CHEST",warmode="CHEST",object="CHEST"}
    local k=kinds[rec.kind]
    if not k or rec.notes=="worldboss" then return end
    local c=self:Continent(rec)
    if not c then return end
    local seen=tonumber(rec.lastSeen) or tonumber(rec.updated) or time()
-- ad50-xOPy59j52_Lw-OQ-c6e4f329
    local d={k=k,n=text(rec.name),id=tonumber(rec.npcID) or 0,c=c,z=tonumber(rec.map),fl=tonumber(rec.floor) or 0,
        x=tonumber(rec.x),y=tonumber(rec.y),ls=seen,t0=seen,level=tonumber(rec.level),
        elite=rec.notes=="rareelite",subtype=rec.kind,notes=text(rec.notes,120),
        respawn=tonumber(rec.respawn),who=text(rec.source,64)}
    if not P:Validate(d) then return end
    -- Resolve a short legacy name / missing NPC ID against existing native pins.
    for _,old in pairs(P:GetDB() or {}) do
        local short=d.n:lower()
        if old.k==d.k and old.c==d.c and old.z==d.z and old.fl==d.fl
            and (old.n:lower()==short or (#d.n==45 and old.n:lower():sub(1,45)==short)) then
            local dist=L:ComputeDistance(d.c,d.z,d.x,d.y,old.c,old.z,old.x,old.y)
            if dist and dist<=(d.k=="CHEST" and 30 or 100) then d.n,d.id=old.n,old.id;break end
        end
    end
    return P:Store(d,localImport==true,sender)
end
function B:ToLegacy(d)
    return {kind=d.subtype or (d.k=="RARE" and "rare" or "chest"),name=d.n,c=d.c,map=d.z,
        x=d.x,y=d.y,npcID=d.id,floor=d.fl,level=d.level,lastSeen=d.ls,updated=d.ls,
        notes=d.notes or (d.elite and "rareelite" or nil),respawn=d.respawn}
end
function B:SendPublic(w)
    if not canSend() then return end
    w.r=realm();w.v=1
    local raw="LCR1:"..D:EncodeForPrint(D:CompressDeflate(S:Serialize(w),{level=5}))
    if #raw>250 then return false end
    return L:GetModule("Comm"):QueuePOIMessage(raw)
end
function B:SendPrivate(w,target)
    if L.CanSendSyncWhisper and not L:CanSendSyncWhisper(target) then return false end
    if not canSend() then return end
    w.r=realm();w.v=1
    self:SendCommMessage("LCR1",S:Serialize(w),"WHISPER",target,"BULK")
end
function B:Request(sender)
    if L.IsSyncPeerBlocked and L:IsSyncPeerBlocked(sender)then return end
    if not canSend() or not allowed(sender,"WHISPER") then return end
    local name=norm(sender)
    if not name or (self.requested[name] and GetTime()-self.requested[name]<300) then return end
-- 2f6df3df.684f5e4b7455775e5c5448.353da113
    self.requested[name]=GetTime()
    self:SendPrivate({op="Q"},sender)
end
function B:Accept(w,sender,via)
    if type(w)~="table" or w.v~=1 or w.r~=realm() or not allowed(sender,via) then return end
    self.peers[norm(sender)]={name=sender,t=GetTime()}
    if w.op=="H" then self:Request(sender)
    elseif w.op=="D" and type(w.records)=="table" and #w.records<=20 then
        for _,r in ipairs(w.records)do self:FromLegacy(r,sender,false)end
    elseif w.op=="Q" and via=="WHISPER" then
        if L.IsSyncPeerBlocked and L:IsSyncPeerBlocked(sender)then return end
        self.replyTimes=self.replyTimes or {}
        local name=norm(sender)
        if self.replyTimes[name] and GetTime()-self.replyTimes[name]<120 then return end
        self.replyTimes[name]=GetTime()
        local keys={};for key in pairs(P:GetDB() or {})do keys[#keys+1]=key end
        self.jobs[name]={target=sender,keys=keys,at=1,next=GetTime()+math.random()}
    end
end
function B:OnCommReceived(prefix,msg,via,sender)
    local startupCore=L:GetModule("Core",true)
    if startupCore and startupCore:StartupHoldActive() then return end
    if prefix~="LCR1" or type(msg)~="string" or #msg>24000 or not allowed(sender,via) then return end
    local ok,w=S:Deserialize(msg);if ok then self:Accept(w,sender,via)end
end
function B:OnChannel(event,msg,sender,...)
    local startupCore=L:GetModule("Core",true)
    if startupCore and startupCore:StartupHoldActive() then return end
    local args={...}
    local c=L:GetModule("Comm",true)
    if not c or type(msg)~="string" or #msg>255 or not allowed(sender,"CHANNEL") then return end
    -- Named channel is payload slot 4 on stock 3.3.5, slot 9 on some clients.
    local match,legacy=false,false
    for _,value in pairs(args)do
        if type(value)=="string" then
            local channel=value:lower()
            if channel==(c.channelName or ""):lower() then match=true end
            if channel=="bblc25c" and c.IsLegacyBridgeEnabled and c:IsLegacyBridgeEnabled() then match=true;legacy=true end
        end
    end
    if not match then return end
    local rates=self.rates
    if legacy then self.legacyRates=self.legacyRates or {};rates=self.legacyRates end
    local window,limit=legacy and 60 or 10,legacy and 18 or 30
    local rate=rates[sender]
    if not rate or GetTime()-rate.t>window then rate={t=GetTime(),n=0};rates[sender]=rate end
    rate.n=rate.n+1;if rate.n>limit then return end
    if msg:sub(1,5)=="LCR1:" then
        local raw=D:DecodeForPrint(msg:sub(6));if not raw then return end
        raw=D:DecompressDeflate(raw);if not raw or #raw>16000 then return end
        local ok,w=S:Deserialize(raw);if ok then self:Accept(w,sender,"CHANNEL")end
-- 76e633:5b7c6d784766446d6f677b:1340fedd
        return
    end
    -- Intended original wire format, including escaped-pipe variants.
    if msg:sub(1,6)=="LCR1||" then msg=msg:gsub("||","|") end
    if msg:sub(1,5)=="LCR1|" then
        local f={};for value in (msg.."|"):gmatch("(.-)|")do f[#f+1]=value end
        if #f~=10 then return end
        self:FromLegacy({kind=f[2],map=f[3],x=f[4],y=f[5],level=f[6],respawn=f[7],name=f[8],notes=f[10]},sender,false)
    elseif msg:sub(1,5)=="LCR1 " then
        -- v1.0.9 strips its own separators. Recover only unambiguous records:
        -- empty drops create a double space between name and notes.
        local kind,map,x,y,level,respawn,tail=msg:match("^LCR1 (%S+) (%d+) ([%d%.]+) ([%d%.]+) (%-?%d+) ([%d%.]+) (.*)$")
        if not kind then return end
        local name,notes=tail:match("^(.-)  (.*)$")
        if not name then return end -- populated fields lost their boundaries
        self:FromLegacy({kind=kind,map=map,x=x,y=y,level=level,respawn=respawn,name=name,notes=notes},sender,false)
    end
end
function B:Pump()
    if not canSend()then wipe(self.jobs);return end
    for name,job in pairs(self.jobs)do
        if not allowed(job.target,"WHISPER")then self.jobs[name]=nil
        elseif GetTime()>=job.next then
            local w={op="D",records={}}
            for i=1,20 do
                local d=(P:GetDB() or {})[job.keys[job.at]];job.at=job.at+1
                if d then w.records[#w.records+1]=self:ToLegacy(d)end
                if job.at>#job.keys then break end
            end
-- 7e1f-FTIjNgkoCiMhKTU-17a1481a
            if #w.records>0 then self:SendPrivate(w,job.target)end
            job.next=GetTime()+.8
            if job.at>#job.keys then self.jobs[name]=nil end
            break
        end
    end
end
function B:OnEnable()
    if L.LEGACY_MODE_ACTIVE then return end
    self:RegisterEvent("CHAT_MSG_CHANNEL","OnChannel");self:RegisterComm("LCR1","OnCommReceived")
    -- Keep the native protocol intact for 0.90/0.90.1 installations.
    local nativeSend=P.SendPublic
    if not self.hooked then
        self.hooked=true
        P.SendPublic=function(self,w)
            local ok=nativeSend(self,w)
            if ok and w.op=="H"then B:SendPublic({op="H"})
            elseif ok and w.op=="D" and next(B.peers)then
                for _,d in ipairs(w.d or {})do B:SendPublic({op="D",records={B:ToLegacy(d)}})end
            end
            return ok
        end
    end
    -- Preserve and import the other fork's existing unscoped saved data once.
    local g=L.db.global
    local legacy=g.rareChest
    if legacy and legacy.records and not legacy.poiImportedToRealm then
        self.legacyImport={source=legacy,records=legacy.records,key=nil,realm=realm()}
    end
    self.driver=CreateFrame("Frame");local elapsed=0
    self.driver:SetScript("OnUpdate",function(_,dt)
        elapsed=elapsed+dt;if elapsed<.5 then return end;elapsed=0
        local Core=L:GetModule("Core",true)
        if not Core or not Core:BackgroundWorkAllowed() then return end
        local job=B.legacyImport
        if job then
            if not Core:ClaimBackgroundSlice("legacy POI import") then return end
            if job.key and job.records[job.key]==nil then job.key=nil end
            local key,record=next(job.records,job.key);job.key=key
            if key then B:FromLegacy(record,nil,false)
            else job.source.poiImportedToRealm=job.realm;B.legacyImport=nil end
            return
        end
        B:Pump()
        for name,peer in pairs(B.peers)do if GetTime()-peer.t>1200 then B.peers[name]=nil end end
    end)
end
function B:OnDisable()
    if self.driver then self.driver:Hide()end
    self:UnregisterAllEvents();self:UnregisterAllComm()
-- e5adaac1.795e4f5a6544664f4d4559.e05af93f
end
