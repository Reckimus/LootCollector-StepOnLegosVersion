-- db67d6:b6918095aa8ba980828a96:36199e52
do
local L=LootCollector
local F=L:GetModule("WFFilters")
local ROW_HEIGHT,VISIBLE=40,7
local function label(parent,value,x,y,width,font)
 local t=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
 t:SetPoint("TOPLEFT",x,y);t:SetWidth(width);t:SetJustifyH("LEFT");t:SetText(value);return t
end
function F:HideResultTooltip()
 local row=self.hoverResult
 if row and GameTooltip:GetOwner()==row then
  GameTooltip:Hide()
  if ShoppingTooltip1 then ShoppingTooltip1:Hide()end
  if ShoppingTooltip2 then ShoppingTooltip2:Hide()end
 end
 self.hoverResult=nil
end
function F:ShowResultTooltip(row)
 local d=row.discovery;if not d then return end
 local link=d.il or (d.i and "item:"..d.i)
 if not link then return end
 self.hoverResult=row
 GameTooltip:SetParent(UIParent);GameTooltip:SetOwner(row,"ANCHOR_RIGHT");GameTooltip:SetFrameStrata("TOOLTIP")
 local cached=GetItemInfo(link)
 local ok=pcall(GameTooltip.SetHyperlink,GameTooltip,link)
 row.tooltipPending=not cached
 if not ok or not cached then
  GameTooltip:ClearLines();GameTooltip:AddLine("Item #"..tostring(d.i or "?"),1,1,1)
  GameTooltip:AddLine(cached and "Item tooltip unavailable."or "Retrieving item information...",.65,.70,.8)
-- dfc4-uZ6PmqWEpo-NhZk-d752dc32
 end
 GameTooltip:Show()
 if ShoppingTooltip1 then ShoppingTooltip1:Hide()end
 if ShoppingTooltip2 then ShoppingTooltip2:Hide()end
 row.compare=IsShiftKeyDown()or (GetCVar and GetCVar("alwaysCompareItems")=="1")
 if ok and cached and row.compare and GameTooltip_ShowCompareItem then GameTooltip_ShowCompareItem(GameTooltip)end
end
function F:ShowResultUpgrades(row, pinned)
 local d=row and row.discovery
 if not (d and d.i) then return false end
 local tooltip=L:GetModule("Tooltip",true)
 if not (tooltip and tooltip.ShowUpgradeBrowser) then return false end
 return tooltip:ShowUpgradeBrowser(d.i,row,pinned,d.il)
end
function F:OpenResult(row)
 local d=row.discovery;local map=L:GetModule("Map",true)
 if not d or not map or not map.FocusOnDiscovery then return end
 self.panel:Hide();map:FocusOnDiscovery(d)
end
function F:ResultLocation(d)
 local zone=L.ResolveZoneDisplay and L.ResolveZoneDisplay(tonumber(d.c)or 0,tonumber(d.z)or 0,tonumber(d.iz)or 0)or "Unknown zone"
 return string.format("%s  |  %.1f, %.1f",zone or "Unknown zone",(tonumber(d.xy and d.xy.x)or 0)*100,(tonumber(d.xy and d.xy.y)or 0)*100)
end
function F:RenderResults()
 if not self.resultScroll then return end
 local hovered=self.hoverResult;local oldDiscovery=hovered and hovered.discovery
 local results=self.results or {}
 FauxScrollFrame_Update(self.resultScroll,#results,VISIBLE,ROW_HEIGHT)
 local offset=math.min(FauxScrollFrame_GetOffset(self.resultScroll)or 0,math.max(0,#results-VISIBLE))
 for i,row in ipairs(self.resultRows)do
  local result=results[offset+i]
  row.discovery=result and result.discovery or nil
  if result then
   local d=result.discovery
   local name,_,quality,_,_,_,_,_,_,texture=GetItemInfo(d.il or d.i)
   row.nameText:SetText(name or result.name)
   local color=ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality or d.q or 1]
-- cfc66f05.765140556a4b6940424a56.187af754
   row.nameText:SetTextColor(color and color.r or 1,color and color.g or 1,color and color.b or 1)
   row.zoneText:SetText(self:ResultLocation(d));row.icon:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
   row:Show()
  else row:Hide()end
 end
 if hovered and (hovered.discovery~=oldDiscovery or not hovered:IsShown())then
  self:HideResultTooltip();if hovered:IsShown()and hovered.discovery then self:ShowResultTooltip(hovered)end
 end
 self.resultCount:SetText(#results.." matching item location"..(#results==1 and ""or "s")..(self.resultJob and "  |  Updating..."or ""))
 if self.resultJob and #results==0 then self.resultEmpty:SetText("Searching saved discoveries...")
 elseif #results==0 then self.resultEmpty:SetText("No matching Worldforged items found.\nTry fewer filters or wait for item details to load.")
 else self.resultEmpty:SetText("")end
 local b=self.tabs and self.tabs.items
 if b then b:SetText((self.tab=="items"and "|cffffd36b"or "|cffc5ccda").."Filtered Items ("..#results..")|r")end
 self.resultHint:SetText(self:DraftIsDirty()and "|cffffd36bShowing applied filters. Apply your changes to update this list.|r"or "Hover: stats  |  Shift: compare  |  Ctrl-hover/right-click: upgrades  |  Click: map")
end
function F:StartResults()
 if self.resultJob then self.resultRescan=true;return end
 local source={}
 for _,d in pairs(L:GetDiscoveriesDB()or {})do
  if self:IsWF(d)and d.g and d.xy and tonumber(d.xy.x)and tonumber(d.xy.y)then source[#source+1]=d end
 end
 self.resultJob={source=source,index=1,rows={},revision=self.revision}
 self.resultWorker:Show();self:RenderResults()
end
function F:ProcessResults()
 local job=self.resultJob;if not job then return end
 local map=L:GetModule("Map",true);local C=L:GetModule("Constants",true)
 local stop=math.min(#job.source,job.index+149)
-- a3b875:290e1f0a3514361f1d1509:d250d1ae
 for i=job.index,stop do
  local d=job.source[i]
  local forbidden=C and C.IsForbiddenZone and C:IsForbiddenZone(d.c,d.z,d.fp)
  local matches
  if map and map.MatchesActiveFilters then matches=map:MatchesActiveFilters(d)else matches=L:DiscoveryPassesFilters(d)end
  if not forbidden and matches then
   local name=GetItemInfo(d.il or d.i)or (d.il and d.il:match("%[(.-)%]"))or ("Item #"..tostring(d.i or "?"))
   job.rows[#job.rows+1]={discovery=d,name=name,sortName=name:lower(),location=self:ResultLocation(d)}
  end
 end
 job.index=stop+1
 if job.index<=#job.source then return end
 table.sort(job.rows,function(a,b)
  if a.sortName~=b.sortName then return a.sortName<b.sortName end
  if a.location~=b.location then return a.location<b.location end
  return tostring(a.discovery.g)<tostring(b.discovery.g)
 end)
 self.results=job.rows;self.resultsRevision=job.revision;self.resultJob=nil;self.resultWorker:Hide();self:RenderResults()
 if self.resultRescan then self.resultRescan=nil;self:StartResults()end
end
function F:UpdateResults()
 if not self.resultWorker then return end
 if self.resultsRevision~=self.revision and not self.resultJob then self:StartResults()end
 if self.resultJob and self.resultJob.revision~=self.revision then self.resultRescan=true end
 if self.resultHint then self.resultHint:SetText(self:DraftIsDirty()and "|cffffd36bShowing applied filters. Apply your changes to update this list.|r"or "Hover: stats  |  Shift: compare  |  Ctrl-hover/right-click: upgrades  |  Click: map")end
end
function F:SelectResultsPage(key)
 if not self.resultWorker then return end
 if key=="items"then
-- afba-sJeGk6yNr4aEjJA-2b21370c
  if not self.resultJob then self:StartResults()end
 else self:StopResults()end
end
function F:StopResults()
 self:HideResultTooltip();self.resultJob=nil;self.resultRescan=nil
 if self.resultWorker then self.resultWorker:Hide()end
end
function F:BuildResultsPage(page)
 self.results={};self.resultRows={}
 self.resultCount=label(page,"Matching item locations",2,-2,530,"GameFontNormal")
 self.resultHint=label(page,"Hover: stats  |  Shift: compare  |  Ctrl-hover/right-click: upgrades  |  Click: map",2,-24,746)
 local refresh=CreateFrame("Button",nil,page,"UIPanelButtonTemplate")
 refresh:SetSize(90,22);refresh:SetPoint("TOPRIGHT",-4,1);refresh:SetText("Refresh");refresh:SetScript("OnClick",function()F:StartResults()end)
 local scroll=CreateFrame("ScrollFrame","LootCollectorWFFilterResultsScroll",page,"FauxScrollFrameTemplate")
 scroll:SetPoint("TOPLEFT",0,-48);scroll:SetSize(728,280)
 scroll:SetScript("OnVerticalScroll",function(self,offset)FauxScrollFrame_OnVerticalScroll(self,offset,ROW_HEIGHT,function()F:RenderResults()end)end)
 scroll:EnableMouseWheel(true)
 scroll:SetScript("OnMouseWheel",function(self,delta)
  local bar=_G[self:GetName().."ScrollBar"]
  if bar then bar:SetValue(math.max(0,math.min(math.max(0,#(F.results or {})-VISIBLE),(FauxScrollFrame_GetOffset(self)or 0)-delta*3))*ROW_HEIGHT)end
 end)
 self.resultScroll=scroll
 for i=1,VISIBLE do
  local row=CreateFrame("Button",nil,page);row:SetSize(724,ROW_HEIGHT-2);row:SetPoint("TOPLEFT",0,-48-(i-1)*ROW_HEIGHT)
  row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight","ADD")
  local bg=row:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetTexture("Interface\\Buttons\\WHITE8X8");bg:SetVertexColor(.10,.13,.18,i%2==1 and .8 or .35)
  row.icon=row:CreateTexture(nil,"ARTWORK");row.icon:SetSize(30,30);row.icon:SetPoint("TOPLEFT",5,-4)
  row.nameText=label(row,"",44,-4,530);row.zoneText=label(row,"",44,-21,650);row.zoneText:SetTextColor(.62,.68,.77)
  local action=label(row,"Show on map >",582,-4,136);action:SetTextColor(.88,.70,.35)
  row:SetScript("OnEnter",function(self)
   F.hoverResult=self
   if IsControlKeyDown() and F:ShowResultUpgrades(self,false) then
    self.ctrlPreview=true
   else
    self.ctrlPreview=false;F:ShowResultTooltip(self)
   end
  end)
-- d8de26c3.002736231c3d1f36343c20.69e11f51
  row:SetScript("OnLeave",function(self)
   if F.hoverResult==self then F:HideResultTooltip()end
   self.ctrlPreview=false
  end)
  row:RegisterForClicks("LeftButtonUp","RightButtonUp")
  row:SetScript("OnClick",function(self,button)
   if button=="RightButton" then F:ShowResultUpgrades(self,true)
   else F:OpenResult(self) end
  end)
  row:SetScript("OnUpdate",function(self,dt)
   if F.hoverResult~=self then return end
   self.tooltipElapsed=(self.tooltipElapsed or 0)+dt;if self.tooltipElapsed<.08 then return end;self.tooltipElapsed=0
   if IsControlKeyDown() then
    if not self.ctrlPreview then
     F:HideResultTooltip();F.hoverResult=self
     self.ctrlPreview=F:ShowResultUpgrades(self,false)
    end
    return
   elseif self.ctrlPreview then
    self.ctrlPreview=false
    local tooltip=L:GetModule("Tooltip",true)
    if tooltip and tooltip.HideUpgradeBrowser then tooltip:HideUpgradeBrowser(false)end
    F:ShowResultTooltip(self)
   end
   local compare=IsShiftKeyDown()or (GetCVar and GetCVar("alwaysCompareItems")=="1")
   if compare~=self.compare or (self.tooltipPending and GetItemInfo(self.discovery.il or self.discovery.i))then F:ShowResultTooltip(self)end
  end)
  row:Hide();self.resultRows[i]=row
 end
 self.resultEmpty=label(page,"",12,-170,700);self.resultEmpty:SetJustifyH("CENTER")
 label(page,"Each row is a saved location. Different rolls and locations remain separate.",2,-337,746)
 self.resultWorker=CreateFrame("Frame");self.resultWorker:Hide();local elapsed=0
 self.resultWorker:SetScript("OnUpdate",function(_,dt)
  elapsed=elapsed+dt;if elapsed<.02 then return end;elapsed=0
  if F.tab~="items"or not F.panel:IsShown()then F:StopResults();return end
  F:ProcessResults()
 end)
 local poll=0
 page:SetScript("OnUpdate",function(_,dt)
  poll=poll+dt;if poll<3 then return end;poll=0
  if not F.resultJob then F:StartResults()end
 end)
end

end

local L=LootCollector
local F=L:GetModule("WFFilters")
-- d600fa:9bbcadb887a684adafa7bb:809fa0b7
local edge="Interface\\Tooltips\\UI-Tooltip-Border"
local function text(parent,value,x,y,font)
 local t=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
 t:SetPoint("TOPLEFT",x,y);t:SetText(value);t:SetJustifyH("LEFT");return t
end
local backdrop={bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1}
local function surface(parent,x,y,w,h,r,g,b)
 local f=CreateFrame("Frame",nil,parent);f:SetPoint("TOPLEFT",x,y);f:SetSize(w,h)
 f:SetBackdrop(backdrop);f:SetBackdropColor(r,g,b,1);f:SetBackdropBorderColor(.17,.20,.26,1)
 return f
end
local function paint(b,hover)
 local active=b.selected or b.primary
 b:SetBackdropColor(active and .22 or (hover and .12 or .075),active and .17 or (hover and .15 or .095),active and .085 or (hover and .20 or .13),1)
 b:SetBackdropBorderColor(active and .67 or .24,active and .49 or .29,active and .22 or .37,1)
end
local function button(parent,label,x,y,width,action)
 local b=CreateFrame("Button",nil,parent)
 b:SetSize(width or 120,26);b:SetPoint("TOPLEFT",x,y);b:SetBackdrop(backdrop)
 local fs=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");fs:SetPoint("CENTER");b:SetFontString(fs)
 b:SetText(label);b:SetScript("OnClick",action)
 b:SetScript("OnEnter",function(self)paint(self,true)end);b:SetScript("OnLeave",function(self)paint(self,false)end)
 b:SetScript("OnMouseDown",function(self)self:GetFontString():SetPoint("CENTER",1,-1)end)
 b:SetScript("OnMouseUp",function(self)self:GetFontString():SetPoint("CENTER",0,0)end)
 paint(b,false);return b
end
local function count(t)local n=0;for _,v in pairs(t or {})do if v then n=n+1 end end;return n end
function F:Count(c)c=c or self:Config();return count(c.types)+count(c.stats)+count(c.effects)+(c.text~=""and 1 or 0)end
function F:AttachViewer(window)
-- 30a0-ia6_qpW0lr-9tak-858a89f9
 if window.wfFiltersButton then return end
 local b=CreateFrame("Button",nil,window,"UIPanelButtonTemplate")
 b:SetSize(148,23);b:SetPoint("TOPRIGHT",-42,-7);b:SetFrameLevel(window:GetFrameLevel()+10)
 b:SetScript("OnClick",function()F:OpenPanel()end);window.wfFiltersButton=b
 self:SyncPanel(false)
end
function F:SelectTab(key)
 if key=="items"and not self.resultWorker then self:BuildResultsPage(self.pages.items) end
 self.tab=key
 for name,p in pairs(self.pages)do if name==key then p:Show()else p:Hide()end end
 for name,b in pairs(self.tabs)do
  b.selected=name==key;paint(b,false)
  b.indicator:SetAlpha(b.selected and 1 or 0)
 end
 self:SyncPanel(false)
 if self.SelectResultsPage then self:SelectResultsPage(key) end
end
function F:DraftIsDirty()
 if not self.draft then return false end
 local a,b=self.draft,self:Config()
 for _,group in ipairs({"types","stats","effects"})do
  for k,v in pairs(a[group])do if v and not b[group][k]then return true end end
  for k,v in pairs(b[group])do if v and not a[group][k]then return true end end
 end
 return a.text~=b.text or a.statMode~=b.statMode or a.effectMode~=b.effectMode or (a.includeUnknown==true)~=(b.includeUnknown==true)
end
function F:SyncPanel(reload)
 local V=L:GetModule("Viewer",true)
 if V and V.window and V.window.wfFiltersButton then
  local n=self:Count();V.window.wfFiltersButton:SetText(n>0 and "WF Filters ("..n..")"or "WF Filters")
-- 494ff4:7d5a4b5e6140624b49415d:0c99600a
 end
 if not self.panel or not self.draft then return end
 if reload then
  for _,b in ipairs(self.checks)do b:SetChecked(self.draft[b.group][b.key]==true)end
  for _,mode in ipairs({"statMode","effectMode"})do
   self.modeButtons[mode]:SetText(self.draft[mode]=="all"and "Match: ALL selected"or "Match: ANY selected")
  end
  self.search:SetText(self.draft.text);self.unknown:SetChecked(self.draft.includeUnknown==true)
 end
 for _,b in ipairs(self.checks)do
  local chosen=self.draft[b.group][b.key]==true
  b.label:SetTextColor(chosen and 1 or .83,chosen and .83 or .86,chosen and .43 or .91)
  b.tint:SetAlpha(chosen and 1 or 0)
 end
 for name,b in pairs(self.tabs)do
  local n=name=="items"and (self.results and #self.results or 0)or count(self.draft[name=="gear"and "types"or name])
  b:SetText((name==self.tab and "|cffffd36b"or "|cffc5ccda")..b.label..(n>0 and " ("..n..")"or "").."|r")
 end
 local n=self:Count(self.draft);local pending=math.max(0,#self.queue-self.head+1)
 local dirty=self:DraftIsDirty()
 self.summary:SetText((n==0 and "All Worldforged items"or n.." filter selections").."  |  "..(dirty and "|cffffd36bUnsaved changes|r"or "|cff83c99bApplied|r"))
 self.status:SetText(pending>0 and "|cffffd36bLoading item details: "..pending.." remaining|r"or "|cff9da9bbYour filters are saved for this character.|r")

 if self.tab=="items"and self.UpdateResults then self:UpdateResults() end
end
function F:BuildPanel()
 if self.panel then return end
 local p=CreateFrame("Frame","LootCollectorWFFilters",UIParent)
 p:SetSize(800,640);p:SetPoint("CENTER");p:SetFrameStrata("DIALOG");p:SetClampedToScreen(true)
-- 8570-ZkFQRXpbeVBSWkY-10d8a59e
 p:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile=edge,tile=false,edgeSize=16,insets={left=4,right=4,top=4,bottom=4}})
 p:SetBackdropColor(.025,.032,.047,1);p:SetBackdropBorderColor(.36,.41,.50,1)
 local header=surface(p,8,-8,784,95,.055,.069,.092)
 local content=surface(p,16,-111,768,362,.042,.053,.073)
 local footer=surface(p,16,-478,768,115,.048,.059,.078)
 header:SetFrameLevel(p:GetFrameLevel());content:SetFrameLevel(p:GetFrameLevel());footer:SetFrameLevel(p:GetFrameLevel())
 p:EnableMouse(true);p:SetMovable(true);p:RegisterForDrag("LeftButton")
 p:SetScript("OnDragStart",p.StartMoving);p:SetScript("OnDragStop",p.StopMovingOrSizing)
 local close=CreateFrame("Button",nil,p,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-3,-3)
 close:SetScript("OnClick",function()p:Hide()end)
 p:SetScript("OnHide",function()F.draft=nil;if F.StopResults then F:StopResults() end end)
 table.insert(UISpecialFrames,"LootCollectorWFFilters")
 text(p,"Worldforged Filters",24,-21,"GameFontNormalLarge")
 text(p,"Refine your discoveries by gear, stats and effects. Applies to the item list and map.",24,-49)
 self.panel=p;self.pages={};self.tabs={};self.checks={};self.modeButtons={}
 local labels={gear="Gear",stats="Stats",effects="Effects",items="Filtered Items"}
 for i,key in ipairs({"gear","stats","effects","items"})do
  local tabKey=key
  local b=button(p,labels[key],24+(i-1)*189,-73,181,function()F:SelectTab(tabKey)end)
  b.label=labels[key];self.tabs[key]=b
  b.indicator=b:CreateTexture(nil,"OVERLAY");b.indicator:SetTexture("Interface\\Buttons\\WHITE8X8");b.indicator:SetVertexColor(.85,.64,.29,1)
  b.indicator:SetPoint("BOTTOMLEFT",1,1);b.indicator:SetPoint("BOTTOMRIGHT",-1,1);b.indicator:SetHeight(2)
  local page=CreateFrame("Frame",nil,p);page:SetPoint("TOPLEFT",24,-116);page:SetSize(752,355);self.pages[key]=page
 end
 local function choices(page,list,group,y,pitch)
  pitch=pitch or 32
  for i,entry in ipairs(list)do
   local key=entry.key;local g=group
   local b=CreateFrame("CheckButton",nil,page,"UICheckButtonTemplate")
-- af455f:6542534679587a53515945:c2a9082d
   b:SetSize(24,24);b:SetHitRectInsets(0,-210,0,0);b:SetPoint("TOPLEFT",((i-1)%3)*249,y-math.floor((i-1)/3)*pitch)
   local label=text(b,entry.label,27,-5);label:SetWidth(210);b.label=label
   b.tint=b:CreateTexture(nil,"BACKGROUND");b.tint:SetTexture("Interface\\Buttons\\WHITE8X8");b.tint:SetVertexColor(.25,.20,.09,.65)
   b.tint:SetPoint("TOPLEFT",-1,2);b.tint:SetSize(235,27);b.tint:SetAlpha(0)
   b.group=g;b.key=key;self.checks[#self.checks+1]=b
   b:SetScript("OnClick",function(self)F.draft[g][key]=self:GetChecked()and true or nil;F:SyncPanel(false)end)
  end
 end
 text(self.pages.gear,"WEAPONS",2,-1,"GameFontNormal")
 text(self.pages.gear,"Any selected type can match. Leave every type clear to allow all gear.",2,-24)
 choices(self.pages.gear,self.weapons,"types",-44,25)
 text(self.pages.gear,"ARMOR & RELICS",2,-199,"GameFontNormal")
 choices(self.pages.gear,self.armors,"types",-219,24)
 text(self.pages.gear,"ACCESSORIES",2,-299,"GameFontNormal")
 choices(self.pages.gear,self.accessories,"types",-320,24)
 local function mode(page,key)
  local k=key
  F.modeButtons[key]=button(page,"",0,-25,190,function()
   F.draft[k]=F.draft[k]=="all"and "any"or "all";F:SyncPanel(true)
  end)
 end
 text(self.pages.stats,"STATS & RATINGS",2,-1,"GameFontNormal");mode(self.pages.stats,"statMode")
 choices(self.pages.stats,self.stats,"stats",-65)
 text(self.pages.stats,"Select the stats you want on the item or in its effects.",2,-333)
 text(self.pages.effects,"EFFECTS & TRIGGERS",2,-1,"GameFontNormal");mode(self.pages.effects,"effectMode")
 choices(self.pages.effects,self.effects,"effects",-65)
 local note=text(self.pages.effects,"On Hit also matches Proc. Equip includes passive bonuses and triggered effects.\n\nUse Tooltip contains below to find a specific affix, spell or custom effect.\n\nThese filters read the whole item tooltip, including base stats and affixes.\nText categories match wording and may not cover every custom effect.",2,-190)
 note:SetWidth(730)
 self.summary=text(p,"",28,-488);self.summary:SetWidth(752)
 text(p,"TOOLTIP CONTAINS",24,-512,"GameFontNormalSmall")
-- a8fd-yu386db31fz-9uo-fde63190
 local edit=CreateFrame("EditBox",nil,p,"InputBoxTemplate");edit:SetSize(410,24);edit:SetPoint("TOPLEFT",165,-505)
 edit:SetAutoFocus(false);edit:SetMaxLetters(150)
 edit:SetScript("OnTextChanged",function(self)if F.draft then F.draft.text=self:GetText();F:SyncPanel(false)end end)
 edit:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
 edit:SetScript("OnEnterPressed",function(self)self:ClearFocus();F:ApplyDraft()end);self.search=edit
 local u=CreateFrame("CheckButton",nil,p,"UICheckButtonTemplate");u:SetSize(24,24);u:SetPoint("TOPLEFT",22,-537)
 text(u,"Include unscanned items while data loads",27,-5)
 u:SetHitRectInsets(0,-300,0,0)
 u:SetScript("OnClick",function(self)F.draft.includeUnknown=self:GetChecked()and true or nil;F:SyncPanel(false)end);self.unknown=u
 self.status=text(p,"",24,-570);self.status:SetWidth(752)
 button(p,"Clear selections",24,-601,145,function()
  F.draft={types={},stats={},effects={},statMode="any",effectMode="any",text=""};F:SyncPanel(true)
 end)
 button(p,"Cancel",512,-601,115,function()p:Hide()end)
 local apply=button(p,"Apply filters",637,-601,139,function()F:ApplyDraft()end)
 apply.primary=true;paint(apply,false)
 self:BuildResultsPage(self.pages.items)
 self:SelectTab("gear")
end
function F:ApplyDraft()
 if not self.draft then return end
 self.search:ClearFocus();L.db.char.wfFilters=self.Copy(self.draft);self:Changed()
 self.status:SetText("|cff7fe5a0Filters applied to the item list and map.|r")
end
function F:OpenPanel()
 self:BuildPanel();self.draft=self.Copy(self:Config());self:SyncPanel(true);self:SelectTab(self.tab or "gear");self.panel:Show()
end
SLASH_LOOTCOLLECTORWFFILTERS1="/lcwf"
SlashCmdList.LOOTCOLLECTORWFFILTERS=function()F:OpenPanel()end
