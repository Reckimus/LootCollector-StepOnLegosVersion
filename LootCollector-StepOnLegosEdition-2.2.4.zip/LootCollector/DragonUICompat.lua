-- Optional integration with the supplied DragonUI CoA world-map module.
-- Loaded before Magnify so only one addon owns the map's scroll hierarchy.
local C={}
_G.LootCollectorDragonUICompat=C
function C:GetMap()
    local d=_G.DragonUI
    local wm=d and d.WorldMap
    if wm and wm.IsApplied and wm.IsApplied() then return wm end
end
function C:ShouldDeferMagnify()
    local d=_G.DragonUI
    local wm=d and d.WorldMap
    return wm and wm.Enabled and wm:Enabled() or false
end
function C:CursorInCanvas()
    local wm=self:GetMap()
    if not wm then return true end
    if wm.IsWindowed and not wm.IsWindowed()then return true end
    local left,top,width,height=self:GetRect()
    if not left then return false end
    local x,y=GetCursorPosition()
    return x>=left and x<=left+width and y<=top and y>=top-height
end
function C:GetRect()
    local wm=self:GetMap()
    if not wm then return end
    if wm.IsWindowed and not wm.IsWindowed()then return end
    local f=WorldMapFrame
    local scale=f:GetEffectiveScale()
    local left,top=f:GetLeft(),f:GetTop()
    if not left or not top or not wm.canvasW or not wm.canvasH then return end
    return (left+(wm.FRAME_X or 16)+(wm.INSET_L or 2))*scale,
        (top-(wm.FRAME_Y or 12)-(wm.SPACER_H or 67))*scale,
        wm.canvasW*scale,wm.canvasH*scale
end
function C:PinSize(size,parent)
    if not self:GetMap() or parent~=WorldMapButton then return size end
    local s=parent:GetEffectiveScale()
    if not s or s<=0 then return size end
    return size*UIParent:GetEffectiveScale()/s
end
function C:AllowHover(pin)
    if not self:GetMap()then return true end
    if pin and pin:GetParent()~=WorldMapButton then return true end
    return self:CursorInCanvas()
end
function C:GetAnchor()
    local wm=self:GetMap()
    if not wm or (wm.IsWindowed and not wm.IsWindowed())then return end
    if not self.anchor then self.anchor=CreateFrame("Frame","LootCollectorDragonCanvas",WorldMapFrame)end
    local f=self.anchor
    f:SetSize(wm.canvasW or 697,wm.canvasH or 465)
    f:ClearAllPoints();f:SetPoint("TOPLEFT",WorldMapFrame,"TOPLEFT",(wm.FRAME_X or 16)+(wm.INSET_L or 2),-((wm.FRAME_Y or 12)+(wm.SPACER_H or 67)))
    return f
end
function C:PlaceFilterButton(button)
    local anchor=self:GetAnchor();if not anchor then return false end
    button:ClearAllPoints();button:SetPoint("BOTTOMRIGHT",anchor,"BOTTOMRIGHT",-8,8)
    return true
end
function C:Refresh()
    if not self:GetMap()then return end
    local L=_G.LootCollector
    if not L or not L.GetModule then return end
    local Map=L:GetModule("Map",true)
    local P=L:GetModule("POI",true)
    local inside=self:CursorInCanvas()
    for _,pins in ipairs({Map and Map.pins or {},Map and Map.clusterPins or {},P and P.worldPins or {}})do
        for _,pin in ipairs(pins)do
            if pin:IsShown()then pin:EnableMouse(inside)end
        end
    end
    if not WorldMapFrame:IsShown()then return end
    local anchor=self:GetAnchor()
    if Map and Map._searchFrame and anchor then
        local search=Map._searchFrame
        if not self.searchAdopted then self.searchScale=search:GetScale();self.searchAdopted=true end
        search:SetParent(anchor);search:ClearAllPoints();search:SetPoint("BOTTOM",anchor,"BOTTOM",0,5)
        search:SetScale(UIParent:GetEffectiveScale()/anchor:GetEffectiveScale())
    elseif Map and Map._searchFrame and self.searchAdopted then
        local search=Map._searchFrame
        search:SetParent(WorldMapDetailFrame);search:SetScale(self.searchScale or 1)
        search:ClearAllPoints();search:SetPoint("BOTTOM",WorldMapDetailFrame,"BOTTOM",0,5)
        self.searchAdopted=nil
    end
end
local driver=CreateFrame("Frame")
local elapsed=0
driver:SetScript("OnUpdate",function(_,dt)
    elapsed=elapsed+dt;if elapsed<.2 then return end;elapsed=0
    C:Refresh()
end)
