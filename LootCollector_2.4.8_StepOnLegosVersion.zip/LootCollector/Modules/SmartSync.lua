-- LCS3 protocol/initial implementation adapted from LootCollector CoA 1.0.16.
-- Copyright (c) 2025 Skulltrail. MIT License; see LICENSE.MD.
-- StepOnLegosEdition: transport integration, validation, bounded indexes and fixes.
-- LootCollector SmartSync v3: bounded, incremental discovery reconciliation.
-- WoW 3.3.5a / Lua 5.1. Protocol intentionally distinct from LCDB1, LCR1 and Questie.
local L = LootCollector
local S = L:NewModule("SmartSync", "AceEvent-3.0", "AceConsole-3.0")
local PREFIX, CHANNEL = "LCS3", "CoASync"
local SECTIONS = {"W", "V", "R", "C"}
local MAX_WIRE, MAX_QUEUE, MAX_IN = 225, 96, 96
local SEND_INTERVAL, HELLO_INTERVAL = 4, 300
local SESSION_LIMIT, RECORDS_PER_TICK = 120, 5
local function clock() return GetTime and GetTime() or 0 end
local function enabled()
  local p = L.db and L.db.profile
  return p and p.sharing and p.sharing.enabled ~= false and p.sharing.publicChannelEnabled ~= false and p.sharing.smartSyncV3 ~= false
end
local function tidy(v, limit)
  return tostring(v or ""):gsub("[%c;~|]", " "):sub(1, limit or 50)
end
local function num(v) return tonumber(v) or 0 end
local function int(v) return math.floor(num(v) + 0.5) end
local function coord(v) return int(num(v) * 10000) end
local function hash(s)
  local h = 5381
  for i=1,#s do h = (h * 33 + s:byte(i)) % 2147483647 end
  return string.format("%08x", h)
end
local function channelID()
  local C = L:GetModule("Comm", true)
  local n = C and tonumber(C.channelId) or 0
  if n > 0 then return n end
  if GetChannelName then
    local id = GetChannelName(CHANNEL)
    return tonumber(id) or 0
  end
  return 0
end
local function rawData()
  local poi=L:GetModule("POI",true)
  return {W=L:GetDiscoveriesDB() or {}, V=L:GetVendorsDB() or {}, R=poi and poi:GetDB() or {}}
end
local function allowedSection(sec)
  local p=L.db and L.db.profile and L.db.profile.poi
  return (sec~="R" and sec~="C") or not p or (p.enabled~=false and p.share~=false)
end
local function recordFor(section,d)
  if type(d)~="table" then return nil end
  if section=="R" or section=="C" then
    local b=L:GetModule("POICompat",true)
    return b and b:ToLegacy(d)
  end
  return d
end
local function busy()
  return (L.IsPaused and L:IsPaused()) or (L.IsZoneIgnored and L:IsZoneIgnored())
      or (InCombatLockdown and InCombatLockdown()) or (GetFramerate and GetFramerate()<40)
end
local function encode(section, d)
  if type(d) ~= "table" then return nil end
  if section == "R" or section == "C" then
    if not d.name or not d.kind or num(d.map) <= 0 or num(d.x) < 0 or num(d.x) > 1 or num(d.y) < 0 or num(d.y) > 1 then return nil end
    local isRare = d.kind == "rare"
    if (section == "R") ~= isRare then return nil end
    local identity = table.concat({tidy(d.kind,12),int(d.map),isRare and tidy(d.name,50):lower() or coord(d.x),isRare and "" or coord(d.y),isRare and "" or tidy(d.name,40):lower()},":")
    local content = table.concat({tidy(d.kind,12),int(d.map),coord(d.x),coord(d.y),int(d.level),int(d.respawn),tidy(d.name,50),tidy(d.drops,45),tidy(d.notes,35)},"~")
    return hash(identity), hash(content), content
  end
  local xy = d.xy
  if type(xy)~="table" or not d.i or num(d.z) <= 0 then return nil end
  local c,z,i,x,y,iz = int(d.c),int(d.z),int(d.i),coord(xy.x),coord(xy.y),int(d.iz)
  if x < 0 or x > 10000 or y < 0 or y > 10000 then return nil end
  local identity = table.concat({section,c,z,i,x,y,iz},":")
  local content = table.concat({c,z,i,x,y,iz,int(d.dt),int(d.q),int(d.it),int(d.ist),tidy(d.itemName or d.vendorName,40)},"~")
  return hash(identity), hash(content), content
end
local function queueLength(q) return q.last - q.first + 1 end
local function push(q, value, maxCount)
  if queueLength(q) >= maxCount then return false end
  q.last = q.last + 1
  q[q.last] = value
  return true
end
local function pop(q)
  if q.first > q.last then return nil end
  local v=q[q.first];q[q.first]=nil;q.first=q.first+1
  if q.first > q.last then q.first=1;q.last=0 end
  return v
end
S.outgoing={first=1,last=0}; S.incoming={first=1,last=0}
S.pending={}; S.peer={}; S.index={}; S.order={}; S.sum={}
S.stats={updated=0,sent=0,received=0,dropped=0,invalid=0,duplicates=0,throttled=0,ack=0}
S.readyAt=math.huge;S.lastSent=0;S.sentSession=0;S.lastHello=nil
function S:Queue(parts, target)
  if not enabled() or self.sentSession>=SESSION_LIMIT then return false end
  local wire = PREFIX..";"..table.concat(parts,";")
  if #wire > MAX_WIRE or wire:find("[%c]") then return false end
  local key = (target or "*")..":"..wire
  if self.pending[key] then return false end
  if not push(self.outgoing,{wire=wire,target=target,key=key,due=clock()+math.random(1,4),expires=clock()+300},MAX_QUEUE) then self.stats.dropped=self.stats.dropped+1; return false end
  self.pending[key]=true
  return true
end
-- Update the additive summary alongside each record: no final full-index sweep.
-- 9339b936.321504112e0f2d04060e12.a3ead893
function S:Put(section,id,fp,content,sourceKey)
  local idx=self.index[section]
  if not idx then return end
  local old=idx[id]
  local refs=self.sourceRefs[section]
  local previous=sourceKey and refs[sourceKey]
  if previous and previous~=id then self:RemoveSource(section,sourceKey) end
  if old and old.fp==fp then return end
  if old and old.sourceKey~=sourceKey and old.fp>fp then return end
  local sum=self.sum[section]
  if old then sum.value=(sum.value-tonumber(hash(id..old.fp),16))%2147483647
  else
    if sum.count>=100000 then return end
    local slot=table.remove(self.freeSlots[section]) or (#self.order[section]+1)
    self.order[section][slot]=id
    sum.count=sum.count+1;self.scanCount=self.scanCount+1
    old={slot=slot}

  end
  idx[id]={fp=fp,content=content,sourceKey=sourceKey,slot=old.slot}
  if sourceKey then refs[sourceKey]=id end
  sum.value=(sum.value+tonumber(hash(id..fp),16))%2147483647
  sum.fp=string.format("%08x",sum.value)
end
-- 539cc8ba.3b1c0d182706240d0f071b.16f73495
function S:RemoveSource(section,key)
  local refs=self.sourceRefs[section]
  local id=refs and refs[key]
  local old=id and self.index[section][id]
  if not old or old.sourceKey~=key then return end
  local sum=self.sum[section]
  sum.value=(sum.value-tonumber(hash(id..old.fp),16))%2147483647
  sum.count=sum.count-1;self.scanCount=self.scanCount-1;sum.fp=string.format("%08x",sum.value)
  self.index[section][id]=nil;refs[key]=nil
  self.order[section][old.slot]=false
  self.freeSlots[section][#self.freeSlots[section]+1]=old.slot
end
function S:IndexRecord(section,d,key)
  if not allowedSection(section) then return end
  local id,fp,content=encode(section,recordFor(section,d))
  if id then self:Put(section,id,fp,content,key) end
end
function S:Rebuild()
  self.outgoing={first=1,last=0};self.pending={}
  self.index={W={},V={},R={},C={}};self.order={W={},V={},R={},C={}}
  self.sum={};self.diffCursor={};self.scanCount=0
  self.sourceRefs={W={},V={},R={},C={}};self.freeSlots={W={},V={},R={},C={}}
  for _,sec in ipairs(SECTIONS) do self.sum[sec]={count=0,value=0,fp="00000000"} end
  self.scanData=rawData();self.scanSection=1;self.scanKey=nil;self.scanning=true
end
function S:ScanStep()
  local Core=L:GetModule("Core",true)
  if Core and Core.ClaimBackgroundSlice and not Core:ClaimBackgroundSlice() then return end
  local budget=RECORDS_PER_TICK
  local start=debugprofilestop and debugprofilestop() or 0
  while budget>0 and self.scanSection<=#SECTIONS do
    if debugprofilestop and debugprofilestop()-start>0.75 then break end
    local section=SECTIONS[self.scanSection]
    local db=section=="W" and self.scanData.W or section=="V" and self.scanData.V or self.scanData.R
    local valid,key,d=pcall(next,db,self.scanKey)
    if not valid then self.scanKey=nil;key,d=next(db,nil) end
    if key==nil then self.scanSection=self.scanSection+1;self.scanKey=nil
    else self.scanKey=key;budget=budget-1;self:IndexRecord(section,d,key) end
  end
  if self.scanSection>#SECTIONS then self.scanData=nil;self.scanning=false end
end
-- 8735abef.3c1b0a1f2001230a08001c.e698f112
function S:OnDiscoveryChanged(_,op,key,d)
  if not self.index.W then return end
  if op=="remove" and key then
    self:RemoveSource("W",key);self:RemoveSource("V",key)
  elseif op=="clear" then
    -- Deletions are local only: LCS3 defines no deletion packet.
    self.reindexAt=clock()+2
  elseif type(d)=="table" then
    local constants=L:GetModule("Constants",true)
    local vendor=constants and d.dt==constants.DISCOVERY_TYPE.BLACKMARKET
    self:IndexRecord(vendor and "V" or "W",d,key)
  end
end
-- 96756c45.2502130639183a13111905.42e7cc0e
function S:OnPOIChanged(d,key)
  if not self.index.W then return end
  self:IndexRecord(d.k=="RARE" and "R" or "C",d,key)
end
function S:Summaries()
  if self.scanning then return end
  for _,sec in ipairs(SECTIONS) do
    local a=self.sum[sec]
    if a and allowedSection(sec) then self:Queue({"SUMMARY",sec,a.count,a.fp}) end
  end
end
function S:SendDiff(sec)
  if self.scanning or not self.order[sec] then return end
  local ids=self.order[sec]
  local limit=#ids
  if limit == 0 then return end
  local start=self.diffCursor and self.diffCursor[sec] or 1
  self.diffCursor=self.diffCursor or {}
  for i=start,math.min(start+7,limit) do
    local id=ids[i]
    local r=self.index[sec][id]
    if r then self:Queue({"DIFF",sec,id,r.fp}) end
  end
  self.diffCursor[sec] = start+8 > limit and 1 or start+8
end
local function isSelfSender(sender)
  if type(sender) ~= "string" then return false end
  local player = UnitName and UnitName("player")
  if type(player) ~= "string" or player == "" then return false end
  local short = sender:match("^([^%-]+)")
  if not short or short:lower() ~= player:lower() then return false end
  local realm = sender:match("%-(.+)$")
  if not realm then return true end
  local own = GetRealmName and GetRealmName()
  if type(own) ~= "string" or own == "" then return false end
  local function norm(v) return v:lower():gsub("%s+", "") end
  return norm(realm) == norm(own)
end
function S:Accept(sender, wire)
  if not enabled() or type(wire)~="string" or #wire>MAX_WIRE or #wire<8 then return end
  if wire:sub(1,#PREFIX+1)~=PREFIX..";" or wire:find("[%c]") then return end
  if type(sender)~="string" or sender=="" or isSelfSender(sender) then return end
  local c=L:GetModule("Comm",true)
  if busy() or not c or not c:CanAcceptPOI(sender,"CHANNEL") then return end
  local p=self.peer[sender]
  local t=clock()
  if not p then
    -- Bounded peer state, including adversarial rotating names.
    local count=0;local stale
    for name,peer in pairs(self.peer) do count=count+1;if t-(peer.lastActivity or 0)>300 then stale=name end end
    if count>=64 then if stale then self.peer[stale]=nil else self.stats.throttled=self.stats.throttled+1;return end end
    p={start=t,count=0,last=-1000,requests=0};self.peer[sender]=p
  end
  if t-p.start>=60 then p.start=t;p.count=0;p.requests=0;p.responses=0;p.seen={} end
  if p.count>=20 then self.stats.throttled=self.stats.throttled+1; return end
  p.count=p.count+1
  p.lastActivity=t
  p.seen=p.seen or {}
  if p.seen[wire] and t-p.seen[wire]<90 then self.stats.duplicates=self.stats.duplicates+1; return end
  if p.count==1 then p.seen={} end
  p.seen[wire]=t
  if push(self.incoming,{sender=sender,wire=wire},MAX_IN) then self.stats.received=self.stats.received+1 else self.stats.dropped=self.stats.dropped+1 end
end
function S:Apply(sec, content, sender)
  if type(content)~="string" or #content>190 then return end
  local a={}
  for f in (content.."~"):gmatch("(.-)~") do
    a[#a+1]=f
    if #a>15 then return end
  end
  if sec=="R" or sec=="C" then
    if #a~=9 then return end
    local kind=a[1]
    if (sec=="R" and kind~="rare") or (sec=="C" and kind~="chest" and kind~="highrisk" and kind~="warmode" and kind~="object") then return end
    local map,x,y=tonumber(a[2]),tonumber(a[3]),tonumber(a[4])
    if not map or map<=0 or not x or not y or x<0 or x>10000 or y<0 or y>10000 then return end
    local rc=L:GetModule("POICompat",true)
    if rc and rc.FromLegacy then
      local ok=rc:FromLegacy({kind=kind,map=map,x=x/10000,y=y/10000,level=tonumber(a[5]),respawn=tonumber(a[6]),name=a[7],drops=a[8],notes=a[9],updated=time()},sender,false)
      if ok then self.stats.updated=self.stats.updated+1;return true end
    end
  else
    if #a~=11 then return end
    for i=1,10 do if tonumber(a[i])==nil then return end end
    local c,z,item,x,y,iz,dt,q,it,ist=unpack(a)
    c=tonumber(c);z=tonumber(z);item=tonumber(item);x=tonumber(x);y=tonumber(y)
    if c<1 or c>4 or z<=0 or z>99999 or item==0 or x<0 or x>10000 or y<0 or y>10000 then return end
    if tonumber(iz)<0 or tonumber(iz)>100 or tonumber(dt)<1 or tonumber(dt)>3
        or tonumber(q)<0 or tonumber(q)>7 or tonumber(it)<0 or tonumber(ist)<0 then return end
    local D=L:GetModule("DBSync",true)
    if D and D.ApplyRecord then
      local constants=L:GetModule("Constants",true)
      if constants and ((sec=="V") ~= (tonumber(dt)==constants.DISCOVERY_TYPE.BLACKMARKET)) then return end
      local stored=D:ApplyRecord(c,z,item,x,y,0,time(),sender,tonumber(q),tonumber(dt),tonumber(it),tonumber(ist),nil,a[11],sender,tonumber(iz))
      if stored then self.stats.updated=self.stats.updated+1;return true end
    end
  end
end
function S:Process(sender,wire)
  local kind,rest=wire:match("^LCS3;([^;]+);?(.*)$")
  if not kind or not enabled() or busy() then return end
  local comm=L:GetModule("Comm",true)
  if not comm or not comm:CanAcceptPOI(sender,"CHANNEL") then return end
  local p=self.peer[sender]
  if not p then return end
  local now=clock()
  if kind=="HELLO" then
    if rest~="3" then return end
    if now-(p.last or -1000)<60 then return end
    p.last=now
    if not self.scanning then self:Summaries() end
  elseif kind=="SUMMARY" then
    local sec,count,fp=rest:match("^([WVRC]);(%d+);(%x+)$")
    if not sec or not allowedSection(sec) or #fp~=8 or num(count)>100000 then return end
    local localSum=self.sum[sec]
    if not self.scanning and localSum and (localSum.fp~=fp or localSum.count~=num(count)) then
      -- Send bounded fingerprint advertisements; no DATA until explicitly requested.
      self:SendDiff(sec)
    end
  elseif kind=="DIFF" then
    local sec,id,fp=rest:match("^([WVRC]);(%x+);(%x+)$")
    if not sec or not allowedSection(sec) or #id~=8 or #fp~=8 or self.scanning then return end
    local localRec=self.index[sec] and self.index[sec][id]
    if (not localRec or localRec.fp<fp) and (p.requests or 0)<16 then
      p.requests=p.requests+1
      self:Queue({"REQUEST",sec,id,fp})
    end
  elseif kind=="REQUEST" then
    local sec,id,fp=rest:match("^([WVRC]);(%x+);(%x+)$")
    if not sec or not allowedSection(sec) or #id~=8 or #fp~=8 then return end
    local record=self.index[sec] and self.index[sec][id]
    if record and record.fp==fp and (p.responses or 0)<12 then
      p.responses=(p.responses or 0)+1
      self:Queue({"DATA",sec,id,fp,record.content})
    end
  elseif kind=="DATA" then
    local sec,id,fp,content=rest:match("^([WVRC]);(%x+);(%x+);(.+)$")
    if not sec or not allowedSection(sec) or #id~=8 or #fp~=8 or not content then return end
    -- Trust neither sender's declared fingerprint nor identity.
    local a={}
    for f in (content.."~"):gmatch("(.-)~") do a[#a+1]=f end
    local numeric=(sec=="R" or sec=="C") and {2,3,4,5,6} or {1,2,3,4,5,6,7,8,9,10}
    for _,i in ipairs(numeric) do
      local n=tonumber(a[i])
      if not n or n~=n or n<=-16777216 or n>=16777216 or n~=math.floor(n) then self.stats.invalid=self.stats.invalid+1;return end
    end
    local reconstructed
    if (sec=="R" or sec=="C") and #a==9 then
      reconstructed={kind=a[1],map=num(a[2]),x=num(a[3])/10000,y=num(a[4])/10000,level=num(a[5]),respawn=num(a[6]),name=a[7],drops=a[8],notes=a[9]}
    elseif #a==11 then
      reconstructed={c=num(a[1]),z=num(a[2]),i=num(a[3]),xy={x=num(a[4])/10000,y=num(a[5])/10000},iz=num(a[6]),dt=num(a[7]),q=num(a[8]),it=num(a[9]),ist=num(a[10]),itemName=a[11]}
    end
    local checkId,checkFp
    if reconstructed then checkId,checkFp=encode(sec,reconstructed) end
    if checkId~=id or checkFp~=fp then self.stats.invalid=self.stats.invalid+1;return end
    local known=self.index[sec] and self.index[sec][id]
    if known and known.fp==fp then self.stats.duplicates=self.stats.duplicates+1;self:Queue({"ACK",sec,id,fp});return end
    if self:Apply(sec,content,sender) then self:Queue({"ACK",sec,id,fp}) else self.stats.invalid=self.stats.invalid+1 end
  elseif kind=="ACK" then
    self.stats.ack=self.stats.ack+1
    -- ACK is intentionally informational. No rebroadcast on acknowledgment.
    return
  end
end
function S:OnChannel(_,message,sender,...)
  -- Client variants expose the base channel name in payload slot 4 or 9.
  local args={...}
  for _,name in pairs(args) do
    if type(name)=="string" and (name:lower()==CHANNEL:lower() or name:lower():match("^%d+%.%s*coasync$")) then
      self:Accept(sender,message);return
    end
  end
end
function S:OnLeave()
  self.readyAt=math.huge
  self.outgoing={first=1,last=0};self.pending={};self.incoming={first=1,last=0}
end
function S:OnEnter()
  local realm=L.GetActiveRealmKey and L:GetActiveRealmKey() or "default"
  if self.realm~=realm or not self.index.W then
    self.realm=realm;self.scanAt=clock()+45
    self.index={};self.order={};self.sum={};self.scanning=false;self.scanData=nil
  end
  self.readyAt=clock()+30
  -- Do not reset the login-session packet cap on each zone/loading screen.
end
-- c8e6fac3.2e09180d321331181a120e.5bce9185
function S:WantsSend(t)
  if not enabled() or busy() or self.scanning or self.scanAt or t<self.readyAt then return false end
  local packet=self.outgoing[self.outgoing.first]
  return packet and t>=packet.due and t<packet.expires and t-self.lastSent>=SEND_INTERVAL and self.sentSession<SESSION_LIMIT or false
end
function S:OnUpdate(elapsed)
  self.tick=(self.tick or 0)+elapsed
  if self.tick<0.1 then return end
  self.tick=0
  if not enabled() then
    self.outgoing={first=1,last=0};self.pending={};self.incoming={first=1,last=0}
    return
  end
  if busy() or clock()<self.readyAt then return end
  local poiAllowed=allowedSection("R")
  if self.poiAllowed~=nil and self.poiAllowed~=poiAllowed then self.reindexAt=clock() end
  self.poiAllowed=poiAllowed
  if self.reindexAt and clock()>=self.reindexAt then self.reindexAt=nil;self:Rebuild() end
  if self.scanAt and clock()>=self.scanAt then self.scanAt=nil;self:Rebuild() end
  if self.scanning then self:ScanStep();return end
  if self.scanAt then return end
  local t=clock()
  if not self.lastHello or t-self.lastHello>=HELLO_INTERVAL then
    if self:Queue({"HELLO","3"}) then self.lastHello=t end
  end
  local start=debugprofilestop and debugprofilestop() or 0
  for i=1,3 do
    if debugprofilestop and debugprofilestop()-start>0.75 then break end
    local packet=pop(self.incoming)
    if not packet then break end
    self:Process(packet.sender,packet.wire)
  end
  -- Drop only a bounded number of expired entries per tick; retain FIFO order.
  for i=1,3 do
    local packet=self.outgoing[self.outgoing.first]
    if not packet or t<packet.expires then break end
    pop(self.outgoing);self.pending[packet.key]=nil;self.stats.dropped=self.stats.dropped+1
  end
  if not self:WantsSend(t) then return end
  local comm=L:GetModule("Comm",true)
  local packet=self.outgoing[self.outgoing.first]
  if comm and comm:TrySendPublic(packet.wire,"smart") then
    pop(self.outgoing);self.pending[packet.key]=nil
    self.lastSent=t;self.sentSession=self.sentSession+1;self.stats.sent=self.stats.sent+1
  end
end
-- e3ae3da6.d7f0e1f4cbeac8e1e3ebf7.51d4f788
function S:Command(cmd)
  cmd=tostring(cmd or ""):lower()
  if cmd=="reindex" then self.reindexAt=clock();return end
  if cmd=="off" or cmd=="on" then L.db.profile.sharing.smartSyncV3=cmd=="on" end
  local s=self:GetStatus()
  print(string.format("LootCollector LCS3: %s; CoASync channel %d; %d indexed; %d active peers; queue %d/%d; sent %d/120; updated %d.",
    enabled() and "enabled" or "disabled",s.channel,s.records,s.peers,s.outgoing,s.incoming,self.sentSession,self.stats.updated))
end
function S:GetStatus()
  local peers=0
  for _,p in pairs(self.peer) do if clock()-(p.lastActivity or 0)<300 then peers=peers+1 end end
  return {channel=channelID(),identity="LootCollector-Discovery-v1",schema=1,protocol=3,building=self.scanning,ready=not self.scanning and not self.scanAt,records=self.scanCount or 0,peers=peers,outgoing=queueLength(self.outgoing),incoming=queueLength(self.incoming),stats=self.stats}
end
function S:OnInitialize()
  if L.LEGACY_MODE_ACTIVE then return end
  self:RegisterEvent("CHAT_MSG_CHANNEL","OnChannel")
  self:RegisterMessage("LootCollector_DiscoveriesUpdated","OnDiscoveryChanged")
  self:RegisterChatCommand("lcsync", function(cmd) self:Command(cmd) end)
  self:RegisterEvent("PLAYER_LEAVING_WORLD","OnLeave")
  self:RegisterEvent("PLAYER_ENTERING_WORLD","OnEnter")
  local frame=CreateFrame("Frame")
  frame:SetScript("OnUpdate",function(_,elapsed) S:OnUpdate(elapsed) end)
  self.frame=frame
  self:OnEnter()
end
