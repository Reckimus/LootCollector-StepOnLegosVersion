-- 73b5e4:113627320d2c0e27252d31:f0f0e426
-- Targeted addon-whisper error silencer. Addition by StepOnLegos, 2.2.5.
-- Default: hide this exact player-not-found error for every source.
-- LC-only filtering remains an optional diagnostic mode. No other system messages
-- are hidden. Local trace records whisper metadata, never message contents.
local L=LootCollector
local S=L:NewModule("SyncSilencer","AceEvent-3.0")
local WINDOW,MANUAL_WINDOW=30,15
S.pending,S.manual={},{}
S.hidden=0
S.sends={}
S.blocked={}
S.cancelled=0
S.rejectedTargets=0
local prefixes={BBLC25AM=true,LC1=true,LCDB1=true,LCPOI1=true,LCR1=true}
-- AceComm appends binary multipart markers to the addon prefix itself.
local function basePrefix(prefix)
    return type(prefix)=="string"and prefix:gsub("[\001-\003]$","")or prefix
end
local function owned(prefix)
    prefix=basePrefix(prefix)
    return prefix and (prefixes[prefix]or prefix==L.addonPrefix)
end
local function key(name)
    if type(name)~="string"then return end
    name=name:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):match("^%s*(.-)%s*$")
    if name==""then return end
    return name:lower()
end
local function short(name)return name and name:match("^[^-]+")end
local function escape(text)return (text:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])","%%%1"))end
local function pattern(template)
    if type(template)~="string"then return end
    local first,last=template:find("%%s")
    if not first then first,last=template:find("%%1%$s")end
    if not first then return end
    return "^"..escape(template:sub(1,first-1)).."(.-)"..escape(template:sub(last+1)).."$"
end
function S:Enabled()return self.active and L.db and L.db.profile.syncErrorSilencer~=false end
function S:Record(table_,target)
    local name=key(target);if not name then return end
    local now=GetTime();table_[name]=now;table_[short(name)]=now
    if not self.nextPrune or now>=self.nextPrune then
        self.nextPrune=now+5
        for n,until_ in pairs(self.blocked)do if until_<=now then self.blocked[n]=nil end end
-- bf2c-QWZ3Yl18Xnd1fWE-8cebab51
        for _,t in ipairs({self.pending,self.manual})do for n,at in pairs(t)do if now-at>WINDOW then t[n]=nil end end end
    end
end
function S:IsPeerBlocked(target)
    local n=key(target);if not n then return false end
    local until_=self.blocked[n]or self.blocked[short(n)]
    return until_ and GetTime()<until_ or false
end
function L:IsSyncPeerBlocked(target)return S:IsPeerBlocked(target)end
-- Validate the character segment before any LC-owned whisper is queued.
-- UTF-8 bytes are permitted for localized names; protocol punctuation is not.
function S:IsValidTarget(target)
    if type(target)~="string" or #target>128 then return false end
    local character,realm=target:match("^([^%-]+)%-(.+)$")
    character=character or target
    if character=="" or not character:match("^[%a\128-\255]+$") then return false end
    if realm and (not realm:match("^[%a%d\128-\255][%a%d\128-\255 %-]*$") or realm:find("[ %-]$")) then return false end
    return true
end
function L:CanSendSyncWhisper(target)
    if not S:IsValidTarget(target) then S.rejectedTargets=S.rejectedTargets+1; return false end
    return not S:IsPeerBlocked(target)
end
-- Some private-server errors replace the real recipient with symbols. Attribute
-- these only to a short window containing LC-only whisper activity. A unique
-- target may be cancelled; ambiguous peers are never arbitrarily blamed.
function S:MaskedRecipient(name,now)
    if self:IsValidTarget(name) then return end
    local candidates,actual={},false
    for i=#self.sends,1,-1 do
        local r=self.sends[i]
        if now-r.at<=3 then
            if not owned(r.prefix) or r.kind=="normal whisper" then return end
            if r.kind=="addon whisper" then actual=true end
            candidates[r.target]=true
        end
    end
    if not actual then return end
    local count,target=0,nil
    for candidate in pairs(candidates) do count=count+1;target=candidate end
    if count==0 then return end
    return count==1 and target or nil,true
end
function S:StopPeer(name)
    local n=key(name);if not n then return end
    self.blocked[n]=GetTime()+120;self.blocked[short(n)]=GetTime()+120
    local function same(target)local k=key(target);return k and (k==n or short(k)==short(n))end
    local poi=L:GetModule("POI",true)
    local compat=L:GetModule("POICompat",true)
    for _,module in pairs({poi=poi,compat=compat})do
        for id,job in pairs(module.jobs or {})do if same(job.target)then module.jobs[id]=nil end end
    end
    if poi then
        if poi.autoPull and same(poi.autoPull.target)then
            if poi.seenSummaries then poi.seenSummaries[poi.autoPull.key]=nil end
            poi.autoPull=nil
        end
        for i=#(poi.autoQueue or {}),1,-1 do if same(poi.autoQueue[i].target)then table.remove(poi.autoQueue,i)end end
    end
    if compat then for id,peer in pairs(compat.peers or {})do if same(peer.name)then compat.peers[id]=nil end end end
    -- The shipped throttle has no public cancellation method. Remove only our
    -- protocol's whisper packets; preserve other destinations and other addons.
    local callbacks={}
    for _,priority in pairs((ChatThrottleLib and ChatThrottleLib.Prio)or {})do
        local ring=priority.Ring
        if ring and type(ring.Remove)=="function"then
            local empty={}
            for pipeName,pipe in pairs(priority.ByName or {})do
                if type(pipe)=="table"then
                    local changed=false
                    for i=#pipe,1,-1 do
                        local msg=pipe[i]
                        if type(msg)=="table"and msg[3]=="WHISPER"and owned(msg[1])and same(msg[4])then
                            table.remove(pipe,i);changed=true;self.cancelled=self.cancelled+1
                            if msg.callbackFn then callbacks[#callbacks+1]={fn=msg.callbackFn,arg=msg.callbackArg}end
                        end
-- c8798d70.725544516e4f6d44464e52.621686de
                    end
                    if changed and #pipe==0 then empty[#empty+1]={name=pipeName,pipe=pipe}end
                end
            end
            for _,entry in ipairs(empty)do ring:Remove(entry.pipe);priority.ByName[entry.name]=nil end
        end
    end
    for _,callback in ipairs(callbacks)do pcall(callback.fn,callback.arg,false)end
end
function S:TraceSend(kind,prefix,target)
    local n=key(target);if not n then return end
    local now=GetTime();local last=self.sends[#self.sends]
    if last and last.target==n and last.kind==kind and last.prefix==prefix and now-last.at<1 then last.at=now;return end
    local source="Caller unavailable"
    if debugstack then
        local stack=debugstack(3,12,0);local lines={}
        for line in stack:gmatch("[^\n]+")do
            if (line:find("AddOns",1,true)or line:find("addons",1,true))and not line:find("SyncSilencer.lua",1,true)then
                lines[#lines+1]=line:sub(1,220);if #lines>=2 then break end
            end
        end
        if #lines>0 then source=table.concat(lines," / ")end
    end
    self.sends[#self.sends+1]={target=n,kind=kind,prefix=prefix,source=source,at=now}
    while #self.sends>60 do table.remove(self.sends,1)end
end
function S:Observe(message)
    if not self.active or type(message)~="string"then return end
    local text=message:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
    local name=self.errorPattern and text:match(self.errorPattern)
    if not name and self.englishPattern then name=text:match(self.englishPattern)end
    local n=key(name);if not n then return end
    local now=GetTime()
    if self.lastError and self.lastError.message==message and self.lastError.at==now then return self.lastError end
    local found={}
    for i=#self.sends,1,-1 do
        local record=self.sends[i]
        if now-record.at<=WINDOW and (record.target==n or short(record.target)==short(n))then
            found[#found+1]={kind=record.kind,prefix=record.prefix,source=record.source,age=now-record.at}
            if #found>=5 then break end
        end
-- cf5074:4463726758795b72707864:069ecf62
    end
    local recipient,masked=self:MaskedRecipient(name,now)
    if masked and recipient then
        for i=#self.sends,1,-1 do
            local record=self.sends[i]
            if record.target==recipient and now-record.at<=3 then
                found[#found+1]={kind=record.kind,prefix=record.prefix,source=record.source,age=now-record.at}
                if #found>=5 then break end
            end
        end
    end
    self.lastError={name=name,key=n,at=now,message=message,sends=found,recipient=recipient,masked=masked}
    local recent=self.pending[n]or self.pending[short(n)]
    if recent and now-recent<=WINDOW then self:StopPeer(name)
    elseif masked and recipient then self:StopPeer(recipient) end
    return self.lastError
end
function S:OnSystemMessage(_,message)self:Observe(message)end
function S:ShowTrace()
    local function printLine(text)DEFAULT_CHAT_FRAME:AddMessage("|cff80cfffLC trace:|r "..text:gsub("|","||"))end
    local error_=self.lastError
    if not error_ then printLine("No player-not-found error observed this session. Run this command after the spam occurs.");return end
    printLine("Latest error: "..error_.name..". Recent whisper activity (correlation, not proof):")
    if error_.masked then printLine(error_.recipient and ("Symbol-name error correlated with LC recipient "..error_.recipient) or "Symbol-name error followed multiple LC recipients; no individual peer was blocked.") end
    if #error_.sends==0 then printLine("No recent whisper send captured. Source is unconfirmed; cached send functions can bypass the hooks.")end
    for _,record in ipairs(error_.sends)do
        printLine(record.kind.."; prefix: "..((record.prefix and record.prefix:gsub("[\001-\003]",function(c)return "<part"..c:byte()..">"end))or "normal chat").."; "..string.format("%.1f",record.age).."s before error")
        printLine(record.source)
    end
end
function S:Outgoing(prefix,_,distribution,target)
    if not self.active or distribution~="WHISPER"then return end
    self:TraceSend("addon whisper",prefix,target)
    if not owned(prefix)then return end
    self:Record(self.pending,target)
end
function S:ManualWhisper(_,distribution,_,target)
    if self.active and distribution=="WHISPER"then self:TraceSend("normal whisper",nil,target);self:Record(self.manual,target)end
end
function S:Filter(_,event,message)
    if event~="CHAT_MSG_SYSTEM"then return false end
    local observed=self:Observe(message)
    if not observed or not self:Enabled()then return false end
    local name,n=observed.name,observed.key
    local now=GetTime();local recent=self.pending[n]or self.pending[short(n)]
    local linked=(recent and now-recent<=WINDOW) or observed.masked
    if L.db.profile.syncErrorSilencerMode=="lc"and not linked then return false end
    -- LC-only mode preserves recent normal-whisper errors. All mode intentionally
    -- hides this one message for every source, including manual whispers.
    local manual=self.manual[n]or self.manual[short(n)]
    if L.db.profile.syncErrorSilencerMode=="lc"and manual and now-manual<=MANUAL_WINDOW then return false end
    -- A filter is invoked once for each chat frame. Count one match per tick/text.
    if self.lastMessage~=message or self.lastMatchAt~=now then self.hidden=self.hidden+1 end
    self.lastMessage,self.lastMatchAt,self.lastName=message,now,name
-- b6a7-Gj0sOQYnBSwuJjo-9d0a6db9
    self.lastLinked=linked and true or false
    return true
end
function S:Command(value)
    local cmd=(value or ""):match("^%s*(.-)%s*$"):lower()
    if cmd=="trace"then self:ShowTrace();return end
    if cmd=="on"or cmd=="off"then L.db.profile.syncErrorSilencer=cmd=="on"
    elseif cmd=="all"or cmd=="lc"then L.db.profile.syncErrorSilencerMode=cmd;L.db.profile.syncErrorSilencer=true end
    local state=L.db.profile.syncErrorSilencer~=false and "on"or "off"
    DEFAULT_CHAT_FRAME:AddMessage("|cff80cfffLootCollector:|r Sync error silencer "..state.." ("..(L.db.profile.syncErrorSilencerMode or "lc").."). Matched this session: "..self.hidden..(self.lastName and ("; last: "..self.lastName.."; recent LC recipient: "..(self.lastLinked and "yes"or "no"))or "").."; queued LC packets cancelled: "..self.cancelled.."; malformed sync targets rejected: "..self.rejectedTargets..". /lcsilence all | lc | on | off | status | trace")
end
function S:OnEnable()
    self.active=true
    -- Always start quietly, including installations left in diagnostic/off mode.
    -- Explicit diagnostic commands still work until the next reload/login.
    L.db.profile.syncErrorSilencer=true
    L.db.profile.syncErrorSilencerMode="all"
    self.englishPattern=pattern("No player named '%s' is currently playing.")
    self.errorPattern=pattern(ERR_CHAT_PLAYER_NOT_FOUND_S or "No player named '%s' is currently playing.")
    if not self.hooked then
        self.hooked=true
        hooksecurefunc("SendAddonMessage",function(...)S:Outgoing(...)end)
        hooksecurefunc("SendChatMessage",function(...)S:ManualWhisper(...)end)
        local throttle=ChatThrottleLib
        if throttle and type(throttle.SendAddonMessage)=="function"then
            hooksecurefunc(throttle,"SendAddonMessage",function(_,priority,prefix,text,distribution,target)
                if S.active and distribution=="WHISPER"then
                    S:TraceSend("queued addon whisper",prefix,target)
                    if owned(prefix) then S:Record(S.pending,target) end
                end
            end)
        end
    end
    self.filter=self.filter or function(...)return S:Filter(...)end
    ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM",self.filter)
    self:RegisterEvent("CHAT_MSG_SYSTEM","OnSystemMessage")
    SLASH_LCWHISPERTRACE1="/lctrace"
    SlashCmdList.LCWHISPERTRACE=function()S:ShowTrace()end
    SLASH_LCSYNCERRORSILENCER1="/lcsilence"
    SlashCmdList.LCSYNCERRORSILENCER=function(value)S:Command(value)end
end
function S:OnDisable()
    self.active=false
    self:UnregisterAllEvents()
    if self.filter then ChatFrame_RemoveMessageEventFilter("CHAT_MSG_SYSTEM",self.filter)end
-- ac1e64c8.a3849580bf9ebc95979f83.28cc5041
end
