-- LootCollector 0.90: discovered chest and silver-dragon rare locations.
-- Kept out of the item/vendor DB so loot maintenance and older peers stay safe.
local L = LootCollector
local POI = L:NewModule("POI", "AceEvent-3.0", "AceComm-3.0")
local Serializer = LibStub("AceSerializer-3.0")
local Deflate = LibStub("LibDeflate")
local PREFIX = "LCPOI1"
local CAP, MAX_BATCH = 10000, 20
local ICONS = { CHEST = "Interface\\AddOns\\LootCollector\\media\\poi-chest", RARE = "Interface\\AddOns\\LootCollector\\media\\poi-rare" }
local COLORS = { CHEST = {1, .75, .16}, RARE = {.78, .84, 1} }
POI.worldPins, POI.miniPins = {}, {}
POI.pending, POI.jobs, POI.spools, POI.rates = {}, {}, {}, {}
POI.lastRequest, POI.lastReplies, POI.localUnits = {}, {}, {}
POI.autoQueue, POI.seenSummaries, POI.helloReplies = {}, {}, {}

local function Say(s) print("|cff80cfffLootCollector:|r " .. s) end
local function finite(n) return type(n) == "number" and n == n and n > -math.huge and n < math.huge end
local function integer(n, lo, hi) return finite(n) and n == math.floor(n) and n >= lo and n <= hi end
local function clean(s, limit)
    if type(s) ~= "string" then return nil end
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|", ""):gsub("[%c]", "")
    s = s:match("^%s*(.-)%s*$")
    if #s == 0 or #s > (limit or 96) then return nil end
    return s
end
local function normalize(s) return L:normalizeSenderName(s or "") end
local function selfSender(s) return normalize(s) == normalize(UnitName("player")) end
local function config()
    if not (L.db and L.db.profile) then return nil end
    L.db.profile.poi = L.db.profile.poi or {}
    return L.db.profile.poi
end
local function active()
    local cfg = config()
    return cfg and cfg.enabled ~= false and not L:IsPaused() and not L:IsZoneIgnored()
end
local function sharing()
    local cfg = config()
    local s = L.db and L.db.profile and L.db.profile.sharing
    return active() and cfg.share ~= false and s and s.enabled
end

function POI:GetDB()
    if not (L.db and L.db.global) then return nil end
    if not L.activeRealmKey then L:ActivateRealmBucket() end
    local bucket = L.db.global.realms and L.db.global.realms[L.activeRealmKey]
    if not bucket then return nil end
    bucket.pointsOfInterest = bucket.pointsOfInterest or {}
    return bucket.pointsOfInterest
end

-- Only read coordinates after selecting the player's actual zone, then restore
-- the browsed map. Never attach a sighting to the zone being browsed remotely.
function POI:GetLocation()
    if self.locating then return nil end
    self.locating = true
    local sc, sz = GetCurrentMapContinent(), GetCurrentMapZone()
    local sf = GetCurrentMapDungeonLevel and GetCurrentMapDungeonLevel() or 0
    SetMapToCurrentZone()
    local c, z = GetCurrentMapContinent(), GetCurrentMapAreaID()
    local floor = GetCurrentMapDungeonLevel and GetCurrentMapDungeonLevel() or 0
    local x, y = GetPlayerMapPosition("player")
    if sc and sz and SetMapZoom then
        SetMapZoom(sc, sz)
        if SetDungeonMapLevel and sf > 0 then SetDungeonMapLevel(sf) end
    end
    self.locating = false
    if not integer(c, 1, 4) or not integer(z, 1, 99999) or z == 14 or z == 15 then return nil end
    if not finite(x) or not finite(y) or x < 0 or y < 0 or x > 1 or y > 1 or (x == 0 and y == 0) then return nil end
    local inInstance, kind = IsInInstance()
    if inInstance and (kind == "pvp" or kind == "arena") then return nil end
    return c, z, floor, x, y
end

-- Public packets contain only primitive, bounded fields. Do not trust peer keys,
-- first-finder claims, or nested data; rebuild a canonical local record instead.
function POI:Validate(d)
    if type(d) ~= "table" or (d.k ~= "CHEST" and d.k ~= "RARE") then return nil end
    local n = clean(d.n)
    if not n or not integer(d.c, 1, 4) or not integer(d.z, 1, 99999) then return nil end
    if d.z == 14 or d.z == 15 then return nil end
    if not finite(d.x) or not finite(d.y) or d.x < 0 or d.y < 0 or d.x > 1 or d.y > 1 or (d.x == 0 and d.y == 0) then return nil end
    if not integer(d.fl or 0, 0, 100) or not integer(d.id or 0, 0, 16777215) then return nil end
    if not integer(d.ls, 946684800, time() + 300) then return nil end
    local t0 = integer(d.t0, 946684800, d.ls) and d.t0 or d.ls
    local loot = L:GetModule("POILoot", true)
    return { k = d.k, n = n, id = d.id or 0, c = d.c, z = d.z, fl = d.fl or 0,
        x = d.x, y = d.y, ls = d.ls, t0 = t0, elite = d.elite == true,
        level = integer(d.level, -1, 255) and d.level or nil,
        close = d.close == true, who = clean(d.who, 64),
        subtype = ({rare="RARE",chest="CHEST",highrisk="CHEST",warmode="CHEST"})[d.subtype]==d.k and d.subtype or nil,
        notes = clean(d.notes,120), drops = clean(d.drops,160),
        respawn = integer(d.respawn,1,10080) and d.respawn or nil,
        loot = loot and loot:ValidateReport(d.loot) or nil }
end

local function identity(d)
    local entity = d.id > 0 and tostring(d.id) or string.lower(d.n)
    return table.concat({"POI", d.k, d.c, d.z, d.fl, entity,
        math.floor(d.x * 10000 + .5), math.floor(d.y * 10000 + .5)}, ":")
end

local function bucketKey(d,byName)
    return table.concat({d.k,d.c,d.z,d.fl,not byName and d.id > 0 and tostring(d.id) or string.lower(d.n)}, "|")
end

function POI:EnsureIndex(db)
    if self.indexDB == db then return end
    self.indexDB, self.entityIndex, self.recordCount = db, {}, 0
    for key,d in pairs(db) do
        local bucket = bucketKey(d)
        self.entityIndex[bucket] = self.entityIndex[bucket] or {}
        self.entityIndex[bucket][key] = true
        local byName=bucketKey(d,true)
        self.entityIndex[byName]=self.entityIndex[byName] or {}
        self.entityIndex[byName][key]=true
        self.recordCount = self.recordCount + 1
    end
end

function POI:FindNear(d)
    local db = self:GetDB()
    if not db then return nil end
    self:EnsureIndex(db)
    local best, bestDist
    local radius = d.k == "CHEST" and 30 or 100
    local candidates={}
    for key in pairs(self.entityIndex[bucketKey(d)] or {}) do candidates[key]=true end
    for key in pairs(self.entityIndex[bucketKey(d,true)] or {}) do candidates[key]=true end
    for key in pairs(candidates) do
        local old = db[key]
        local sameEntity = (d.id > 0 and old.id == d.id) or ((d.id == 0 or old.id == 0) and string.lower(old.n) == string.lower(d.n))
        if old.k == d.k and old.c == d.c and old.z == d.z and old.fl == d.fl and sameEntity then
            local dist = L:ComputeDistance(d.c, d.z, d.x, d.y, old.c, old.z, old.x, old.y)
            -- Fallback is deliberately small if this custom zone has no yard scale.
            local near = dist and dist <= radius
            if not dist then
                dist = math.sqrt((d.x - old.x)^2 + (d.y - old.y)^2)
                near = dist <= (d.k == "CHEST" and .003 or .01)
            end
            if near and (not bestDist or dist < bestDist) then best, bestDist = key, dist end
        end
    end
    return best
end

function POI:Changed()
    self.summary = nil
    self.dirty = true
end

function POI:Store(data, localObservation, sender, unitGUID)
    local d = self:Validate(data)
    local db = self:GetDB()
    if not d or not db then return nil end
    self:EnsureIndex(db)
    local key = unitGUID and self.localUnits[unitGUID] or nil
    if key and (not db[key] or db[key].z ~= d.z or db[key].fl ~= d.fl) then key = nil end
    key = key or self:FindNear(d) or identity(d)
    local old = db[key]
    if not old then
        if self.recordCount >= CAP then return nil end
        old = d
        db[key] = old
        local bucket = bucketKey(d)
        self.entityIndex[bucket] = self.entityIndex[bucket] or {}
        self.entityIndex[bucket][key] = true
        local byName=bucketKey(d,true)
        self.entityIndex[byName]=self.entityIndex[byName] or {}
        self.entityIndex[byName][key]=true
        self.recordCount = self.recordCount + 1
    else
        old.t0 = math.min(old.t0 or d.t0, d.t0)
        if d.ls >= old.ls then
            -- Keep a close-range observation instead of replacing it with a
            -- distant player's approximate position during a later sighting.
            if d.close or not old.close then old.x, old.y = d.x, d.y end
            old.ls, old.close = d.ls, old.close or d.close
            old.level, old.elite = d.level or old.level, d.elite or old.elite
        end
    end
    old.subtype=d.subtype or old.subtype
    old.notes=d.notes or old.notes
    old.drops=d.drops or old.drops
    old.respawn=d.respawn or old.respawn
    local loot=L:GetModule("POILoot",true)
    if loot and loot:IsNewer(d.loot,old.loot) then old.loot=d.loot end
    if unitGUID then self.localUnits[unitGUID] = key end
    if localObservation then
        old.localSeen = time()
        old.who = UnitName("player")
        if sharing() and (not old.lastShared or time() - old.lastShared >= 300) then
            local s = L.db.profile.sharing
            self.pending[key] = time() + (s.delayed and (tonumber(s.delaySeconds) or 30) or 0)
        end
    else old.receivedFrom = clean(sender, 64) end
    self:Changed()
    return old, key
end

function POI:WireRecord(d)
    local anonymous = L.db.profile.sharing.anonymous
    return {k=d.k, n=d.n, id=d.id, c=d.c, z=d.z, fl=d.fl, x=d.x, y=d.y,
        ls=d.ls, t0=d.t0, close=d.close, level=d.level, elite=d.elite,
        who=not anonymous and d.who or nil, subtype=d.subtype, notes=d.notes, drops=d.drops, respawn=d.respawn,
        loot=L:GetModule("POILoot",true) and L:GetModule("POILoot"):WireReport(d.loot,anonymous) or nil}
end

local function npcID(guid)
    if type(guid) ~= "string" then return 0 end
    if guid:match("^0x[Ff]13[05]") then return tonumber(guid:sub(7, 12), 16) or 0 end
    return tonumber(guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")) or 0
end

function POI:ObserveRare(unit)
    if not active() or config().trackRares == false then return end
    if not UnitExists(unit) or UnitIsPlayer(unit) then return end
    local class = UnitClassification(unit)
    if class ~= "rare" and class ~= "rareelite" then return end
    -- Dead corpses do not count as a live rare sighting.
    if UnitIsDead(unit) then return end
    local guid, name = UnitGUID(unit), clean(UnitName(unit))
    if not guid or not name then return end
    self.unitTimes = self.unitTimes or {}
    local close = CheckInteractDistance and CheckInteractDistance(unit, 4) or false
    local prev = self.unitTimes[guid]
    if prev and GetTime() - prev.t < 60 and (prev.close or not close) then return end
    local c, z, fl, x, y = self:GetLocation()
    if not c then return end
    local d = {k="RARE", n=name, id=npcID(guid), c=c, z=z, fl=fl, x=x, y=y,
        ls=time(), t0=time(), elite=class == "rareelite", level=UnitLevel(unit), close=close}
    if self:Store(d, true, nil, guid) then self.unitTimes[guid] = {t=GetTime(), close=close} end
end

function POI:IsChestName(name)
    name = clean(name)
    if not name then return false end
    local lower = string.lower(name)
    return lower:find("chest", 1, true) ~= nil or lower:find("treasure coffer", 1, true) ~= nil
        or lower:find("footlocker", 1, true) ~= nil or lower:find("strongbox", 1, true) ~= nil
end

function POI:ObserveChest(name, close, manual)
    if not active() or config().trackChests == false then return end
    name = clean(name)
    if not name or (not manual and not self:IsChestName(name)) then return end
    local c, z, fl, x, y = self:GetLocation()
    if not c then return end
    return self:Store({k="CHEST", n=name, id=0, c=c, z=z, fl=fl, x=x, y=y,
        ls=time(), t0=time(), close=close == true}, true)
end

function POI:ScanWorldTooltip()
    if not active() or config().trackChests == false then return end
    if not GameTooltip or not GameTooltip:IsShown() then return end
    if GetMouseFocus() ~= WorldFrame then return end
    local _, unit = GameTooltip:GetUnit()
    local item = GameTooltip:GetItem()
    if unit or item or UnitExists("mouseover") then self.chestCandidate = nil; return end
    local line = _G.GameTooltipTextLeft1
    local name = line and clean(line:GetText())
    if not self:IsChestName(name) then self.chestCandidate = nil; return end
    local now = GetTime()
    self.chestCandidate = {n=name, t=now}
    if self.lastChestName == name and now - (self.lastChestTime or 0) < 5 then return end
    self.lastChestName, self.lastChestTime = name, now
    self:ObserveChest(name, false)
end

function POI:OnLootOpened()
    local loot=L:GetModule("POILoot",true)
    if loot then loot:OnLootOpened();return end
    local candidate = self.chestCandidate
    if candidate and GetTime() - candidate.t <= 1.5 and not UnitExists("mouseover")
        and not (IsFishingLoot and IsFishingLoot()) then
        self:ObserveChest(candidate.n, true)
    end
    self.chestCandidate = nil
end

function POI:CanReceive(sender, distribution)
    if not sharing() or not sender or selfSender(sender) then return false end
    local Comm = L:GetModule("Comm", true)
    return Comm and Comm:CanAcceptPOI(sender, distribution)
end

function POI:Envelope(op)
    return {v=1, op=op, r=L:GetActiveRealmKey()}
end

function POI:SendPublic(wire)
    if not sharing() then return false end
    local Comm = L:GetModule("Comm", true)
    if not Comm then return false end
    local packed = Deflate:CompressDeflate(Serializer:Serialize(wire), {level=5})
    local encoded = Deflate:EncodeForPrint(packed)
    local n = math.ceil(#encoded / 205)
    if n > 6 then return false end
    self.sequence = (self.sequence or 0) + 1
    local id = tostring(time()) .. "-" .. self.sequence
    for i=1,n do
        if not Comm:QueuePOIMessage(PREFIX .. ":" .. id .. ":" .. i .. ":" .. n .. ":" .. encoded:sub((i-1)*205+1, i*205)) then return false end
    end
    return true
end

function POI:SendPrivate(wire, distribution, target)
    if not sharing() then return end
    local Comm=L:GetModule("Comm",true)
    if not Comm or not Comm:CanSendPOI() then return end
    self:SendCommMessage(PREFIX, Serializer:Serialize(wire), distribution, target, "BULK")
end

function POI:RequestSync(target)
    if not sharing() then Say("Enable sharing before requesting chest/rare locations."); return end
    local wire = self:Envelope("Q")
    if target and target ~= "" then
        target = clean(target, 64)
        if not target or not target:match("^[%a\128-\255][%a\128-\255%-]*$") then Say("Use /lcpoi sync PlayerName"); return end
        wire.all = true
        self:SendPrivate(wire, "WHISPER", target)
        Say("Requesting chest/rare history from " .. target .. " (0.90 required).")
    else
        local c, z, fl = self:GetLocation()
        if not c then return end
        local key = c .. ":" .. z .. ":" .. fl
        if time() - (self.lastRequest[key] or 0) < 60 then return end
        self.lastRequest[key] = time()
        wire.c, wire.z, wire.fl = c, z, fl
        self:SendPublic(wire)
    end
end

-- Automatically discover peers and pull their complete history. Public
-- messages carry only a summary; large transfers stay on throttled whispers.
function POI:GetSummary()
    if self.summary then return self.summary end
    local count, sum = 0, 0
    for _,d in pairs(self:GetDB() or {}) do
        local loot=L:GetModule("POILoot",true)
        local key=identity(d)..(loot and loot:ReportKey(d.loot) or "")
        local hash=5381
        for i=1,#key do hash=(hash*33+key:byte(i))%2147483647 end
        sum=(sum+hash)%2147483647
        count=count+1
    end
    self.summary={count=count,sig=tostring(count).."-"..string.format("%.0f",sum)}
    return self.summary
end

function POI:Hello(ask)
    local w=self:Envelope("H")
    local summary=self:GetSummary()
    w.count,w.sig,w.ask=summary.count,summary.sig,ask==true
    return w
end

function POI:Announce()
    if not sharing() or not L.channelReady then return end
    if self.lastAnnounced and GetTime()-self.lastAnnounced<30 then return end
    if self:SendPublic(self:Hello(true)) then
        self.lastAnnounced=GetTime()
        self.nextHello=GetTime()+300+math.random()*30
    end
end

function POI:ConsiderPeer(wire,sender)
    if not integer(wire.count,0,CAP) or type(wire.sig)~="string" or #wire.sig>32 then return end
    local name=normalize(sender)
    if not name or wire.count==0 or wire.sig==self:GetSummary().sig then return end
    local key=name..":"..wire.sig
    if self.seenSummaries[key] then return end
    for _,job in ipairs(self.autoQueue) do if job.key==key then return end end
    if self.autoPull and self.autoPull.key==key then return end
    if #self.autoQueue>=10 then return end
    self.autoQueue[#self.autoQueue+1]={target=sender,key=key}
end

function POI:PumpAutoSync()
    local Comm=L:GetModule("Comm",true)
    if not L.channelReady or not Comm or not Comm:CanSendPOI() then return end
    local now=GetTime()
    if not self.nextHello then self.nextHello=now+18 end
    if now>=self.nextHello then self:Announce() end
    if self.autoPull then
        local job=self.autoPull
        if not self:CanReceive(job.target,"WHISPER") or now-job.started>600
            or (now-job.started>15 and now-(job.lastData or job.started)>10) then
            self.autoPull=nil
        else return end
    end
    local job=table.remove(self.autoQueue,1)
    if not job or not self:CanReceive(job.target,"WHISPER") then return end
    self.autoRequested=self.autoRequested or {}
    local name=normalize(job.target)
    if self.autoRequested[name] and now-self.autoRequested[name]<120 then
        self.autoQueue[#self.autoQueue+1]=job
        return
    end
    self.autoRequested[name]=now
    local w=self:Envelope("Q");w.all=true
    self:SendPrivate(w,"WHISPER",job.target)
    job.started=now
    self.autoPull=job
    self.seenSummaries[job.key]=true
end

function POI:AcceptWire(wire, sender, distribution)
    if type(wire) ~= "table" or wire.v ~= 1 or wire.r ~= L:GetActiveRealmKey() then return end
    if not self:CanReceive(sender, distribution) then return end
    if wire.op == "H" then
        if not integer(wire.count,0,CAP) or type(wire.sig)~="string" or #wire.sig>32 then return end
        self:ConsiderPeer(wire,sender)
        local name=normalize(sender)
        if wire.ask and name and (not self.helloReplies[name] or GetTime()-self.helloReplies[name]>60) then
            self.helloReplies[name]=GetTime()
            self:SendPrivate(self:Hello(false),"WHISPER",sender)
        end
    elseif wire.op == "D" then
        if type(wire.d) ~= "table" or #wire.d > MAX_BATCH then return end
        for i=1,#wire.d do self:Store(wire.d[i], false, sender) end
        if self.autoPull and normalize(self.autoPull.target)==normalize(sender) then self.autoPull.lastData=GetTime() end
    elseif wire.op == "Q" then
        local all = wire.all == true and distribution == "WHISPER"
        if not all and (not integer(wire.c,1,4) or not integer(wire.z,1,99999) or not integer(wire.fl or 0,0,100)) then return end
        local name = normalize(sender)
        if not name or time() - (self.lastReplies[name] or 0) < 120 then return end
        self.lastReplies[name] = time()
        local jobs = 0
        for _ in pairs(self.jobs) do jobs=jobs+1 end
        if jobs >= 5 then return end
        local keys = {}
        for key, d in pairs(self:GetDB() or {}) do
            if all or (d.c == wire.c and d.z == wire.z and d.fl == (wire.fl or 0)) then
                keys[#keys+1] = key
                if #keys >= CAP then break end
            end
        end
        if #keys > 0 then self.jobs[name] = {target=sender, keys=keys, at=1, next=GetTime()+math.random()*3} end
    end
end

-- Public transport uses a distinct header so 0.8.x clients ignore it instead
-- of treating object/NPC records as item discoveries. Reassembly is bounded.
function POI:OnChannel(event, msg, sender, _, _, _, _, _, _, channelName)
    local Comm = L:GetModule("Comm", true)
    if not Comm or string.upper(channelName or "") ~= string.upper(Comm.channelName or "") then return end
    if type(msg) ~= "string" or #msg > 255 or not self:CanReceive(sender, "CHANNEL") then return end
    local id, part, total, data = msg:match("^LCPOI1:([%d%-]+):(%d+):(%d+):(.+)$")
    part, total = tonumber(part), tonumber(total)
    if not id or #id > 24 or not integer(total,1,6) or not integer(part,1,total) or #data > 205 then return end
    local rate = self.rates[sender]
    if not rate or GetTime()-rate.t > 10 then rate={t=GetTime(), n=0}; self.rates[sender]=rate end
    rate.n = rate.n + 1
    if rate.n > 60 then return end
    local key = sender .. ":" .. id
    local spool = self.spools[key]
    if not spool then
        local count=0
        for _ in pairs(self.spools) do count=count+1 end
        if count >= 40 then return end
        spool={t=GetTime(), n=total, pieces={}};self.spools[key]=spool
    end
    if spool.n ~= total then return end
    spool.pieces[part] = data
    for i=1,total do if not spool.pieces[i] then return end end
    self.spools[key]=nil
    local encoded = table.concat(spool.pieces)
    local compressed = Deflate:DecodeForPrint(encoded)
    if not compressed then return end
    local unpacked = Deflate:DecompressDeflate(compressed)
    if not unpacked or #unpacked > 16000 then return end
    local ok, wire = Serializer:Deserialize(unpacked)
    if ok then self:AcceptWire(wire, sender, "CHANNEL") end
end

function POI:OnCommReceived(prefix, message, distribution, sender)
    if prefix ~= PREFIX or type(message) ~= "string" or #message > 24000 or not self:CanReceive(sender, distribution) then return end
    self.aceRates = self.aceRates or {}
    local r = self.aceRates[sender]
    if not r or GetTime()-r.t > 10 then r={t=GetTime(),n=0};self.aceRates[sender]=r end
    r.n=r.n+1
    if r.n > 30 then return end
    local ok, wire = Serializer:Deserialize(message)
    if ok then self:AcceptWire(wire, sender, distribution) end
end

function POI:PumpNetwork()
    local now = GetTime()
    for key, spool in pairs(self.spools) do if now-spool.t > 60 then self.spools[key]=nil end end
    if not sharing() then
        wipe(self.pending);wipe(self.jobs);wipe(self.autoQueue);self.autoPull=nil
        return
    end
    self:PumpAutoSync()
    local db = self:GetDB() or {}
    for key, at in pairs(self.pending) do
        if time() >= at and L.channelReady then
            local d=db[key]
            self.pending[key]=nil
            if d then
                local wire=self:Envelope("D");wire.d={self:WireRecord(d)}
                if self:SendPublic(wire) then d.lastShared=time()
                else self:SendPublic(self:Hello(true)) end
            end
            break
        end
    end
    -- A bounded batch on the normal AceComm throttle, never a chat flood.
    for name, job in pairs(self.jobs) do
        if not self:CanReceive(job.target, "WHISPER") then
            self.jobs[name]=nil
        elseif now >= job.next then
            local wire=self:Envelope("D");wire.d={}
            for i=1,MAX_BATCH do
                local d=db[job.keys[job.at]]
                job.at=job.at+1
                if d then wire.d[#wire.d+1]=self:WireRecord(d) end
                if job.at > #job.keys or #Serializer:Serialize(wire)>12000 then break end
            end
            if #wire.d > 0 then self:SendPrivate(wire,"WHISPER",job.target) end
            job.next=now+.8
            if job.at > #job.keys then self.jobs[name]=nil end
            break
        end
    end
end

function POI:Passes(d, search)
    if not active() then return false end
    local f=L:GetFilters()
    if f.hideAll then return false end
    local cf=L.db.char.mapFilters or {}
    if (d.k=="CHEST" and cf.showChests==false) or (d.k=="RARE" and cf.showRares==false) then return false end
    return not search or search=="" or string.find(string.lower(d.n .. " " .. (d.k=="CHEST" and "chest treasure" or "rare silver dragon")),search,1,true)~=nil
end

function POI:HideTooltip()
    local tip=GameTooltip
    if self.tipOwner and tip and tip:GetOwner()==self.tipOwner then
        tip:Hide()
        tip:SetParent(self.oldTipParent or UIParent)
        tip:SetScale(self.oldTipScale or 1)
    end
    self.tipOwner=nil
end

-- Use the SAME native tooltip as WF, including its fullscreen map parent.
-- Only compensate the inherited scale while this addon owns the tooltip.
function POI:Tooltip(pin)
    local compat=_G.LootCollectorDragonUICompat
    if compat and not compat:AllowHover(pin)then return end
    local d=pin.record
    if not d or not GameTooltip then return end
    local tip=GameTooltip
    if not self.tipOwner then
        self.oldTipParent=tip:GetParent()
        self.oldTipScale=tip:GetScale()
    end
    local parent=WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame or UIParent
    tip:SetParent(parent)
    tip:SetScale(UIParent:GetEffectiveScale()/parent:GetEffectiveScale())
    tip:SetFrameStrata("TOOLTIP")
    tip:SetFrameLevel(math.max(pin:GetFrameLevel(),parent:GetFrameLevel())+100)
    self.settingTooltip=true
    tip:SetOwner(pin,"ANCHOR_RIGHT")
    self.settingTooltip=false
    tip:ClearLines()
    local age=math.max(0,time()-(d.ls or time()))
    local seen=age<60 and "just now" or age<3600 and (math.floor(age/60).."m ago")
        or age<86400 and (math.floor(age/3600).."h ago") or (math.floor(age/86400).."d ago")
    local name=d.n or "Discovery"
    if #name>48 then name=name:sub(1,45).."..." end
    tip:AddLine(name,unpack(COLORS[d.k]))
    local kind=d.k=="CHEST" and "Chest" or (d.elite and "Rare elite" or "Rare")
    tip:AddLine(string.format("%s - %.1f, %.1f (approx.)",kind,d.x*100,d.y*100),1,1,1)
    tip:AddLine("Last seen: "..seen,.75,.75,.75)
    if IsAltKeyDown and IsAltKeyDown() then
        if d.level then tip:AddLine("Level "..(d.level==-1 and "??" or d.level),1,1,1) end
        if d.who and not L.db.profile.hidePlayerNames then tip:AddLine("Reported by: "..d.who,.75,.75,.75) end
    end
    tip:AddLine("Historical location; respawn unknown",.65,.65,.65)
    tip:Show()
    self.tip=tip
    self.tipOwner=pin
    pin._tipRecord,pin._tipSeen,pin._tipAlt=pin.record,pin.record.ls,IsAltKeyDown and IsAltKeyDown() or false
    local loot=L:GetModule("POILoot",true)
    if loot then loot:ShowForPin(pin) end
end

-- Some 3.3.5 map replacements let the pan/area frame consume OnEnter even
-- though the pin is visible. Hit-test our visible buttons while over map chrome.
function POI:PollHover()
    local focus=GetMouseFocus()
    local mapShown=WorldMapFrame and WorldMapFrame:IsShown()
    local mapFocus=focus==WorldMapButton or focus==WorldMapDetailFrame or focus==WorldMapFrame
        or focus==WorldMapScrollFrame or focus==WorldMapFrameAreaFrame
    local miniFocus=focus==Minimap
    local candidate
    if MouseIsOver and not (DropDownList1 and DropDownList1:IsShown()) then
        local pins=mapShown and self.worldPins or self.miniPins
        for _,pin in ipairs(pins) do
            if pin.record and pin:IsShown() and (focus==pin or mapFocus or miniFocus) and MouseIsOver(pin) then
                candidate=pin;break
            end
        end
    end
    if candidate then
        self.polledOwner=candidate
        if self.tipOwner~=candidate or not GameTooltip:IsShown() or GameTooltip:GetOwner()~=candidate
            or candidate._tipRecord~=candidate.record or candidate._tipSeen~=candidate.record.ls
            or candidate._tipAlt~=(IsAltKeyDown and IsAltKeyDown() or false) then self:Tooltip(candidate) end
    elseif self.polledOwner then
        local old=self.polledOwner
        self.polledOwner=nil
        if self.tipOwner==old then self:HideTooltip() end
    end
end

function POI:MakePin(parent)
    local Map=L:GetModule("Map",true)
    local pin=parent==WorldMapButton and Map and Map.BuildPin and Map:BuildPin(true) or CreateFrame("Button",nil,parent)
    pin:SetFrameStrata(parent:GetFrameStrata())
    pin:SetFrameLevel(parent:GetFrameLevel()+25)
    pin:EnableMouse(true)
    pin.icon=pin.texture or pin:CreateTexture(nil,"ARTWORK");pin.icon:SetAllPoints(pin)
    if pin.qualityGlow then pin.qualityGlow:Hide() end
    if pin.unlootedOutline then pin.unlootedOutline:Hide() end
    pin.border=pin:CreateTexture(nil,"OVERLAY");pin.border:SetTexture("Interface\\Buttons\\UI-Quickslot2");pin.border:SetAllPoints(pin)
    pin:RegisterForClicks("LeftButtonUp","RightButtonUp")
    pin:SetScript("OnEnter",function(self) POI:Tooltip(self) end)
    pin:SetScript("OnLeave",function(self)
        if POI.tipOwner==self then POI:HideTooltip() end
    end)
    -- Recover hover information if a map/layout refresh swallowed OnEnter.
    pin:SetScript("OnUpdate",function(self,delta)
        self.hoverElapsed=(self.hoverElapsed or 0)+delta
        if self.hoverElapsed<.15 then return end
        self.hoverElapsed=0
        if not self.record or not self:IsShown() or GetMouseFocus()~=self then return end
        local alt=IsAltKeyDown and IsAltKeyDown() or false
        if not POI.tip or not POI.tip:IsShown() or POI.tipOwner~=self
            or self._tipRecord~=self.record or self._tipSeen~=self.record.ls or self._tipAlt~=alt then
            POI:Tooltip(self)
        end
    end)
    pin:SetScript("OnClick",function(self,button)
        if not self.record then return end
        if button=="RightButton" and IsShiftKeyDown() then
            L.db.char.hiddenPOI=L.db.char.hiddenPOI or {};L.db.char.hiddenPOI[self.key]=true
            POI:HideTooltip();POI:Changed();POI:DrawWorld();POI:DrawMinimap()
        elseif button=="LeftButton" then
            local d=self.record
            Say(string.format("%s: %.1f, %.1f (approximate; last seen %s)",d.n,d.x*100,d.y*100,date("%Y-%m-%d %H:%M",d.ls)))
        end
    end)
    return pin
end

local function hidePins(pins, first)
    for i=first or 1,#pins do pins[i]:Hide();pins[i].record=nil end
end
function POI:Hidden(key) return L.db.char.hiddenPOI and L.db.char.hiddenPOI[key] end
function POI:Paint(pin,d,key,size)
    local compat=_G.LootCollectorDragonUICompat
    pin:EnableMouse(not compat or compat:AllowHover(pin))
    if compat then size=compat:PinSize(size,pin:GetParent())end
    local parent=pin:GetParent()
    local level=parent:GetFrameLevel()
    if parent==WorldMapButton then
        level=math.max(level,WorldMapFrame:GetFrameLevel(),WorldMapFrameAreaFrame and WorldMapFrameAreaFrame:GetFrameLevel() or 0,
            WorldMapScrollFrame and WorldMapScrollFrame:GetFrameLevel() or 0)
    end
    pin:SetFrameLevel(level+25)
    pin.record,pin.key=d,key
    pin:SetSize(size,size);pin.icon:SetTexture(ICONS[d.k]);pin.border:SetVertexColor(unpack(COLORS[d.k]));pin.border:Hide();pin:Show()
end

function POI:DrawWorld()
    if self.locating then return end
    if not active() or not WorldMapFrame or not WorldMapFrame:IsShown() or not WorldMapButton or not WorldMapDetailFrame then hidePins(self.worldPins);return end
    local Map=L:GetModule("Map",true)
    local w,h,offsetX,offsetY
    if Map and Map.GetPinGeometry then w,h,offsetX,offsetY=Map:GetPinGeometry() end
    if not w then
        local frame=WorldMapDetailFrame or WorldMapButton
        w,h=frame:GetWidth(),frame:GetHeight()
        local left,top=frame:GetLeft(),frame:GetTop()
        local pl,pt=WorldMapButton:GetLeft(),WorldMapButton:GetTop()
        if not w or w<=0 or not left or not top or not pl or not pt then hidePins(self.worldPins);return end
        offsetX,offsetY=left-pl,top-pt
    end
    local c,z=GetCurrentMapContinent(),GetCurrentMapAreaID()
    local floor=GetCurrentMapDungeonLevel and GetCurrentMapDungeonLevel() or 0
    local Map=L:GetModule("Map",true)
    local search=Map and Map._searchBox and string.lower(Map._searchBox:GetText() or "") or ""
    local i=1
    for key,d in pairs(self:GetDB() or {}) do
        if d.c==c and d.z==z and d.fl==floor and not self:Hidden(key) and self:Passes(d,search) then
            local pin=self.worldPins[i] or self:MakePin(WorldMapButton);self.worldPins[i]=pin;i=i+1
            self:Paint(pin,d,key,L:GetFilters().pinSize or 17)
            pin:ClearAllPoints();pin:SetPoint("CENTER",WorldMapButton,"TOPLEFT",offsetX+d.x*w,offsetY-d.y*h)
        end
    end
    hidePins(self.worldPins,i)
end

function POI:DrawMinimap()
    local f=L:GetFilters()
    if not active() or not f.showMinimap or f.hideAll or not Minimap then hidePins(self.miniPins);return end
    local Map=L:GetModule("Map",true)
    if not Map or not Map.GetPlayerLocation then return end
    local c,z,x,y=Map:GetPlayerLocation()
    if not c or not z or not x or not y or (x==0 and y==0) then hidePins(self.miniPins);return end
    -- Never draw underground-floor pins on the surface minimap.
    local floor=GetCurrentMapDungeonLevel and GetCurrentMapDungeonLevel() or 0
    if WorldMapFrame and WorldMapFrame:IsShown() and GetCurrentMapAreaID()~=z then floor=self.playerFloor or 0
    else self.playerFloor=floor end
    local radius=Minimap.GetViewRadius and Minimap:GetViewRadius()
    if not radius or radius<=0 then hidePins(self.miniPins);return end
    local width,height=Minimap:GetWidth(),Minimap:GetHeight()
    local facing=GetPlayerFacing() or 0
    local rotate=GetCVar("rotateMinimap")=="1"
    local cs,sn=math.cos(facing),math.sin(facing)
    local i=1
    for key,d in pairs(self:GetDB() or {}) do
        if d.c==c and d.z==z and d.fl==floor and not self:Hidden(key) and self:Passes(d) then
            local dist,dx,dy=L:ComputeDistance(c,z,x,y,c,z,d.x,d.y)
            if dist and dx and dy and dist < radius*.85 then
                if rotate then dx,dy=dx*cs-dy*sn,dx*sn+dy*cs end
                local pin=self.miniPins[i] or self:MakePin(Minimap);self.miniPins[i]=pin;i=i+1
                self:Paint(pin,d,key,f.minimapPinSize or 14)
                pin:ClearAllPoints();pin:SetPoint("CENTER",Minimap,"CENTER",dx*width/(radius*2),-dy*height/(radius*2))
            end
        end
    end
    hidePins(self.miniPins,i)
end

function POI:Slash(message)
    local cmd,arg=(message or ""):match("^%s*(%S*)%s*(.-)%s*$")
    cmd=string.lower(cmd or "")
    local cfg=config();if not cfg then return end
    L.db.char.mapFilters=L.db.char.mapFilters or {}
    local f=L.db.char.mapFilters
    if cmd=="chests" or cmd=="rares" then
        local key=cmd=="chests" and "showChests" or "showRares"
        if arg=="on" then f[key]=true elseif arg=="off" then f[key]=false else f[key]=f[key]==false end
        Say(cmd .. " pins " .. (f[key] and "shown." or "hidden."))
    elseif cmd=="on" or cmd=="off" then cfg.enabled=cmd=="on";Say("Chest/rare tracking " .. (cfg.enabled and "enabled." or "disabled."))
    elseif cmd=="share" then
        if arg=="on" then cfg.share=true elseif arg=="off" then cfg.share=false else cfg.share=cfg.share==false end
        Say("Chest/rare sharing " .. (cfg.share and "enabled (uses main Sharing setting)." or "disabled."))
    elseif cmd=="sync" then
        if arg=="" then self:Announce() else self:RequestSync(arg) end
    elseif cmd=="chest" then self:ObserveChest(arg~="" and arg or "Treasure Chest",true,true)
    elseif cmd=="rare" then self:ObserveRare("target")
    elseif cmd=="unhide" then L.db.char.hiddenPOI={};Say("Hidden chest/rare pins restored.")
    elseif cmd=="status" then
        local chests,rares=0,0
        for _,d in pairs(self:GetDB() or {}) do if d.k=="CHEST" then chests=chests+1 else rares=rares+1 end end
        Say(string.format("2.1.3: %d chest locations; %d rare locations on %s. Sharing: %s",chests,rares,L:GetActiveRealmKey(),sharing() and "on" or "off"))
    else
        Say("/lcpoi on|off; chests on|off; rares on|off; share on|off; sync [PlayerName]; status; unhide")
        Say("/lcpoi chest [name] marks a chest at your position; /lcpoi rare records a targeted silver-dragon rare.")
    end
    self:Changed();self:DrawWorld();self:DrawMinimap()
end

function POI:OnInitialize()
    if L.LEGACY_MODE_ACTIVE then return end
    self:GetDB()
    L.db.char.mapFilters=L.db.char.mapFilters or {}
    if L.db.char.mapFilters.showChests==nil then L.db.char.mapFilters.showChests=true end
    if L.db.char.mapFilters.showRares==nil then L.db.char.mapFilters.showRares=true end
    SLASH_LOOTCOLLECTORPOI1="/lcpoi"
    SlashCmdList.LOOTCOLLECTORPOI=function(msg) POI:Slash(msg) end
end

function POI:OnEnable()
    if L.LEGACY_MODE_ACTIVE then return end
    if hooksecurefunc and not self.tooltipHooked then
        self.tooltipHooked=true
        hooksecurefunc(GameTooltip,"SetOwner",function(tip,owner)
            if POI.tipOwner and owner~=POI.tipOwner and not POI.settingTooltip then
                tip:SetScale(POI.oldTipScale or 1)
                POI.tipOwner=nil
                POI.polledOwner=nil
            end
        end)
    end
    self:RegisterComm(PREFIX,"OnCommReceived")
    self:RegisterEvent("CHAT_MSG_CHANNEL","OnChannel")
    self:RegisterEvent("PLAYER_TARGET_CHANGED",function() POI:ObserveRare("target") end)
    self:RegisterEvent("UPDATE_MOUSEOVER_UNIT",function() POI:ObserveRare("mouseover") end)
    self:RegisterEvent("LOOT_OPENED","OnLootOpened")
    self:RegisterEvent("WORLD_MAP_UPDATE",function() POI.dirty=true end)
    local function zoneChanged()
        POI.chestCandidate=nil;wipe(POI.unitTimes or {});wipe(POI.localUnits)
        POI.nextHello=GetTime()+18
        POI.dirty=true
    end
    self:RegisterEvent("PLAYER_ENTERING_WORLD",zoneChanged)
    self:RegisterEvent("ZONE_CHANGED_NEW_AREA",zoneChanged)
    if GameTooltip then
        GameTooltip:HookScript("OnTooltipSetUnit",function() POI.chestCandidate=nil end)
        GameTooltip:HookScript("OnTooltipSetItem",function() POI.chestCandidate=nil end)
    end
    self.driver=CreateFrame("Frame")
    local elapsed,slow=0,0
    self.driver:SetScript("OnUpdate",function(_,delta)
        elapsed=elapsed+delta;slow=slow+delta
        if elapsed>=.2 then
            elapsed=0
            if POI.tipOwner and (not active() or not POI.tipOwner:IsShown()) then POI:HideTooltip() end
            if active() then POI:PollHover() end
            POI:ScanWorldTooltip()
            POI:PumpNetwork()
            if POI.dirty or (WorldMapFrame and WorldMapFrame:IsShown()) then POI:DrawWorld();POI.dirty=false end
        end
        if slow>=.5 then
            slow=0;POI:ObserveRare("target");POI:DrawMinimap()
            for sender,rate in pairs(POI.rates) do if GetTime()-rate.t>60 then POI.rates[sender]=nil end end
            for sender,rate in pairs(POI.aceRates or {}) do if GetTime()-rate.t>60 then POI.aceRates[sender]=nil end end
        end
    end)
end

function POI:OnDisable()
    if self.driver then self.driver:Hide() end
    self:UnregisterAllEvents();self:UnregisterAllComm()
    self:HideTooltip()
    hidePins(self.worldPins);hidePins(self.miniPins)
end
