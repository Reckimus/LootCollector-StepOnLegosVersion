-- d600fa:9bbcadb887a684adafa7bb:809fa0b7
local L=LootCollector
local F=L:GetModule("WFFilters")
local ROW_HEIGHT,VISIBLE=40,7
local function label(parent,value,x,y,width,font)
 local t=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
 t:SetPoint("TOPLEFT",x,y);t:SetWidth(width);t:SetJustifyH("LEFT");t:SetText(value);return t
end
function F:HideResultTooltip()
 local row=self.hoverResult
 if row and GameTooltip:GetOwner()==row then
  GameTooltip:Hide()
  if ShoppingTooltip1 then ShoppingTooltip1:Hide()end
  if ShoppingTooltip2 then ShoppingTooltip2:Hide()end
 end
 self.hoverResult=nil
end
function F:ShowResultTooltip(row)
 local d=row.discovery;if not d then return end
 local link=d.il or (d.i and "item:"..d.i)
 if not link then return end
 self.hoverResult=row
 GameTooltip:SetParent(UIParent);GameTooltip:SetOwner(row,"ANCHOR_RIGHT");GameTooltip:SetFrameStrata("TOOLTIP")
 local cached=GetItemInfo(link)
 local ok=pcall(GameTooltip.SetHyperlink,GameTooltip,link)
 row.tooltipPending=not cached
 if not ok or not cached then
  GameTooltip:ClearLines();GameTooltip:AddLine("Item #"..tostring(d.i or "?"),1,1,1)
  GameTooltip:AddLine(cached and "Item tooltip unavailable."or "Retrieving item information...",.65,.70,.8)
 end
 GameTooltip:Show()
 if ShoppingTooltip1 then ShoppingTooltip1:Hide()end
 if ShoppingTooltip2 then ShoppingTooltip2:Hide()end
 row.compare=IsShiftKeyDown()or (GetCVar and GetCVar("alwaysCompareItems")=="1")
 if ok and cached and row.compare and GameTooltip_ShowCompareItem then GameTooltip_ShowCompareItem(GameTooltip)end
-- 30a0-ia6_qpW0lr-9tak-858a89f9
end
function F:OpenResult(row)
 local d=row.discovery;local map=L:GetModule("Map",true)
 if not d or not map or not map.FocusOnDiscovery then return end
 self.panel:Hide();map:FocusOnDiscovery(d)
end
function F:ResultLocation(d)
 local zone=L.ResolveZoneDisplay and L.ResolveZoneDisplay(tonumber(d.c)or 0,tonumber(d.z)or 0,tonumber(d.iz)or 0)or "Unknown zone"
 return string.format("%s  |  %.1f, %.1f",zone or "Unknown zone",(tonumber(d.xy and d.xy.x)or 0)*100,(tonumber(d.xy and d.xy.y)or 0)*100)
end
function F:RenderResults()
 if not self.resultScroll then return end
 local hovered=self.hoverResult;local oldDiscovery=hovered and hovered.discovery
 local results=self.results or {}
 FauxScrollFrame_Update(self.resultScroll,#results,VISIBLE,ROW_HEIGHT)
 local offset=math.min(FauxScrollFrame_GetOffset(self.resultScroll)or 0,math.max(0,#results-VISIBLE))
 for i,row in ipairs(self.resultRows)do
  local result=results[offset+i]
  row.discovery=result and result.discovery or nil
  if result then
   local d=result.discovery
   local name,_,quality,_,_,_,_,_,_,texture=GetItemInfo(d.il or d.i)
   row.nameText:SetText(name or result.name)
   local color=ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality or d.q or 1]
   row.nameText:SetTextColor(color and color.r or 1,color and color.g or 1,color and color.b or 1)
   row.zoneText:SetText(self:ResultLocation(d));row.icon:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
   row:Show()
  else row:Hide()end
 end
 if hovered and (hovered.discovery~=oldDiscovery or not hovered:IsShown())then
  self:HideResultTooltip();if hovered:IsShown()and hovered.discovery then self:ShowResultTooltip(hovered)end
 end
 self.resultCount:SetText(#results.." matching item location"..(#results==1 and ""or "s")..(self.resultJob and "  |  Updating..."or ""))
 if self.resultJob and #results==0 then self.resultEmpty:SetText("Searching saved discoveries...")
-- 494ff4:7d5a4b5e6140624b49415d:0c99600a
 elseif #results==0 then self.resultEmpty:SetText("No matching Worldforged items found.\nTry fewer filters or wait for item details to load.")
 else self.resultEmpty:SetText("")end
 local b=self.tabs and self.tabs.items
 if b then b:SetText((self.tab=="items"and "|cffffd36b"or "|cffc5ccda").."Filtered Items ("..#results..")|r")end
 self.resultHint:SetText(self:DraftIsDirty()and "|cffffd36bShowing applied filters. Apply your changes to update this list.|r"or "Hover: item stats  |  Hold Shift: compare  |  Click: show location")
end
function F:StartResults()
 if self.resultJob then self.resultRescan=true;return end
 local source={}
 for _,d in pairs(L:GetDiscoveriesDB()or {})do
  if self:IsWF(d)and d.g and d.xy and tonumber(d.xy.x)and tonumber(d.xy.y)then source[#source+1]=d end
 end
 self.resultJob={source=source,index=1,rows={},revision=self.revision}
 self.resultWorker:Show();self:RenderResults()
end
function F:ProcessResults()
 local job=self.resultJob;if not job then return end
 local map=L:GetModule("Map",true);local C=L:GetModule("Constants",true)
 local stop=math.min(#job.source,job.index+149)
 for i=job.index,stop do
  local d=job.source[i]
  local forbidden=C and C.IsForbiddenZone and C:IsForbiddenZone(d.c,d.z,d.fp)
  local matches
  if map and map.MatchesActiveFilters then matches=map:MatchesActiveFilters(d)else matches=L:DiscoveryPassesFilters(d)end
  if not forbidden and matches then
   local name=GetItemInfo(d.il or d.i)or (d.il and d.il:match("%[(.-)%]"))or ("Item #"..tostring(d.i or "?"))
   job.rows[#job.rows+1]={discovery=d,name=name,sortName=name:lower(),location=self:ResultLocation(d)}
  end
 end
 job.index=stop+1
 if job.index<=#job.source then return end
 table.sort(job.rows,function(a,b)
  if a.sortName~=b.sortName then return a.sortName<b.sortName end
-- 8570-ZkFQRXpbeVBSWkY-10d8a59e
  if a.location~=b.location then return a.location<b.location end
  return tostring(a.discovery.g)<tostring(b.discovery.g)
 end)
 self.results=job.rows;self.resultsRevision=job.revision;self.resultJob=nil;self.resultWorker:Hide();self:RenderResults()
 if self.resultRescan then self.resultRescan=nil;self:StartResults()end
end
function F:UpdateResults()
 if not self.resultWorker then return end
 if self.resultsRevision~=self.revision and not self.resultJob then self:StartResults()end
 if self.resultJob and self.resultJob.revision~=self.revision then self.resultRescan=true end
 if self.resultHint then self.resultHint:SetText(self:DraftIsDirty()and "|cffffd36bShowing applied filters. Apply your changes to update this list.|r"or "Hover: item stats  |  Hold Shift: compare  |  Click: show location")end
end
function F:SelectResultsPage(key)
 if not self.resultWorker then return end
 if key=="items"then
  if not self.resultJob then self:StartResults()end
 else self:StopResults()end
end
function F:StopResults()
 self:HideResultTooltip();self.resultJob=nil;self.resultRescan=nil
 if self.resultWorker then self.resultWorker:Hide()end
end
function F:BuildResultsPage(page)
 self.results={};self.resultRows={}
 self.resultCount=label(page,"Matching item locations",2,-2,530,"GameFontNormal")
 self.resultHint=label(page,"Hover: item stats  |  Hold Shift: compare  |  Click: show location",2,-24,746)
 local refresh=CreateFrame("Button",nil,page,"UIPanelButtonTemplate")
 refresh:SetSize(90,22);refresh:SetPoint("TOPRIGHT",-4,1);refresh:SetText("Refresh");refresh:SetScript("OnClick",function()F:StartResults()end)
 local scroll=CreateFrame("ScrollFrame","LootCollectorWFFilterResultsScroll",page,"FauxScrollFrameTemplate")
 scroll:SetPoint("TOPLEFT",0,-48);scroll:SetSize(728,280)
 scroll:SetScript("OnVerticalScroll",function(self,offset)FauxScrollFrame_OnVerticalScroll(self,offset,ROW_HEIGHT,function()F:RenderResults()end)end)
 scroll:EnableMouseWheel(true)
 scroll:SetScript("OnMouseWheel",function(self,delta)
  local bar=_G[self:GetName().."ScrollBar"]
-- af455f:6542534679587a53515945:c2a9082d
  if bar then bar:SetValue(math.max(0,math.min(math.max(0,#(F.results or {})-VISIBLE),(FauxScrollFrame_GetOffset(self)or 0)-delta*3))*ROW_HEIGHT)end
 end)
 self.resultScroll=scroll
 for i=1,VISIBLE do
  local row=CreateFrame("Button",nil,page);row:SetSize(724,ROW_HEIGHT-2);row:SetPoint("TOPLEFT",0,-48-(i-1)*ROW_HEIGHT)
  row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight","ADD")
  local bg=row:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetTexture("Interface\\Buttons\\WHITE8X8");bg:SetVertexColor(.10,.13,.18,i%2==1 and .8 or .35)
  row.icon=row:CreateTexture(nil,"ARTWORK");row.icon:SetSize(30,30);row.icon:SetPoint("TOPLEFT",5,-4)
  row.nameText=label(row,"",44,-4,530);row.zoneText=label(row,"",44,-21,650);row.zoneText:SetTextColor(.62,.68,.77)
  local action=label(row,"Show on map >",582,-4,136);action:SetTextColor(.88,.70,.35)
  row:SetScript("OnEnter",function(self)F:ShowResultTooltip(self)end)
  row:SetScript("OnLeave",function(self)if F.hoverResult==self then F:HideResultTooltip()end end)
  row:SetScript("OnClick",function(self)F:OpenResult(self)end)
  row:SetScript("OnUpdate",function(self,dt)
   if F.hoverResult~=self then return end
   self.tooltipElapsed=(self.tooltipElapsed or 0)+dt;if self.tooltipElapsed<.08 then return end;self.tooltipElapsed=0
   local compare=IsShiftKeyDown()or (GetCVar and GetCVar("alwaysCompareItems")=="1")
   if compare~=self.compare or (self.tooltipPending and GetItemInfo(self.discovery.il or self.discovery.i))then F:ShowResultTooltip(self)end
  end)
  row:Hide();self.resultRows[i]=row
 end
 self.resultEmpty=label(page,"",12,-170,700);self.resultEmpty:SetJustifyH("CENTER")
 label(page,"Each row is a saved location. Different rolls and locations remain separate.",2,-337,746)
 self.resultWorker=CreateFrame("Frame");self.resultWorker:Hide();local elapsed=0
 self.resultWorker:SetScript("OnUpdate",function(_,dt)
  elapsed=elapsed+dt;if elapsed<.02 then return end;elapsed=0
  if F.tab~="items"or not F.panel:IsShown()then F:StopResults();return end
  F:ProcessResults()
 end)
 local poll=0
 page:SetScript("OnUpdate",function(_,dt)
  poll=poll+dt;if poll<3 then return end;poll=0
  if not F.resultJob then F:StartResults()end
 end)
-- a8fd-yu386db31fz-9uo-fde63190
end
