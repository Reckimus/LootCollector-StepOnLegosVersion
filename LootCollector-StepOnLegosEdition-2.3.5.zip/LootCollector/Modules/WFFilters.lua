-- 0cb6ed:d0f7e6f3ccedcfe6e4ecf0:5a588306
local L=LootCollector
local F=L:NewModule("WFFilters","AceEvent-3.0")
F.revision=0;F.cache={};F.queue={};F.queued={};F.retry={};F.head=1
F.weapons={};F.armors={}
F.accessories={{key="slot:INVTYPE_NECK",label="Necklaces"},{key="slot:INVTYPE_FINGER",label="Rings"},{key="slot:INVTYPE_TRINKET",label="Trinkets"}}
local accessorySlots={INVTYPE_NECK=true,INVTYPE_FINGER=true,INVTYPE_TRINKET=true}
local weaponNames={"1H Axes","2H Axes","Bows","Guns","1H Maces","2H Maces","Polearms","1H Swords","2H Swords","Staves","Fist Weapons","Daggers","Thrown","Crossbows","Wands","Fishing Poles"}
for i,name in ipairs(weaponNames)do F.weapons[i]={key="4:"..(29+i),label=name}end
for i,name in ipairs({"Cloth","Leather","Mail","Plate","Shields","Librams","Idols","Totems","Sigils"})do F.armors[i]={key="1:"..i,label=name}end
F.stats={
 {key="str",label="Strength",api={"ITEM_MOD_STRENGTH_SHORT"},words={"strength"}},
 {key="agi",label="Agility",api={"ITEM_MOD_AGILITY_SHORT"},words={"agility"}},
 {key="sta",label="Stamina",api={"ITEM_MOD_STAMINA_SHORT"},words={"stamina"}},
 {key="int",label="Intellect",api={"ITEM_MOD_INTELLECT_SHORT"},words={"intellect"}},
 {key="spi",label="Spirit",api={"ITEM_MOD_SPIRIT_SHORT"},words={"spirit"}},
 {key="ap",label="Attack Power",api={"ITEM_MOD_ATTACK_POWER_SHORT","ITEM_MOD_RANGED_ATTACK_POWER_SHORT","ITEM_MOD_FERAL_ATTACK_POWER_SHORT"},words={"attack power"}},
 {key="sp",label="Spell Power",api={"ITEM_MOD_SPELL_POWER_SHORT","ITEM_MOD_SPELL_DAMAGE_DONE_SHORT"},words={"spell power","spell damage"}},
 {key="heal",label="Healing Power",api={"ITEM_MOD_SPELL_HEALING_DONE_SHORT"},words={"healing power","healing done"}},
 {key="crit",label="Critical Strike",api={"ITEM_MOD_CRIT_RATING_SHORT","ITEM_MOD_SPELL_CRIT_RATING_SHORT","ITEM_MOD_MELEE_CRIT_RATING_SHORT","ITEM_MOD_RANGED_CRIT_RATING_SHORT"},words={"critical strike","crit rating"}},
 {key="haste",label="Haste",api={"ITEM_MOD_HASTE_RATING_SHORT","ITEM_MOD_SPELL_HASTE_RATING_SHORT","ITEM_MOD_MELEE_HASTE_RATING_SHORT","ITEM_MOD_RANGED_HASTE_RATING_SHORT"},words={"haste"}},
 {key="hit",label="Hit Rating",api={"ITEM_MOD_HIT_RATING_SHORT","ITEM_MOD_SPELL_HIT_RATING_SHORT","ITEM_MOD_MELEE_HIT_RATING_SHORT","ITEM_MOD_RANGED_HIT_RATING_SHORT"},words={"hit rating"}},
 {key="expertise",label="Expertise",api={"ITEM_MOD_EXPERTISE_RATING_SHORT"},words={"expertise"}},
 {key="arp",label="Armor Penetration",api={"ITEM_MOD_ARMOR_PENETRATION_RATING_SHORT"},words={"armor penetration"}},
 {key="pen",label="Spell Penetration",api={"ITEM_MOD_SPELL_PENETRATION_SHORT"},words={"spell penetration"}},
 {key="def",label="Defense",api={"ITEM_MOD_DEFENSE_SKILL_RATING_SHORT"},words={"defense rating","defense skill"}},
 {key="dodge",label="Dodge",api={"ITEM_MOD_DODGE_RATING_SHORT"},words={"dodge"}},
 {key="parry",label="Parry",api={"ITEM_MOD_PARRY_RATING_SHORT"},words={"parry"}},
 {key="block",label="Block",api={"ITEM_MOD_BLOCK_RATING_SHORT","ITEM_MOD_BLOCK_VALUE_SHORT"},words={"block rating","block value"}},
 {key="resil",label="Resilience",api={"ITEM_MOD_RESILIENCE_RATING_SHORT"},words={"resilience"}},
 {key="regen",label="Mana Regen / MP5",api={"ITEM_MOD_MANA_REGENERATION_SHORT"},words={"mana per 5","mana every 5","mana regeneration","mp5"}},
 {key="health",label="Health",api={"ITEM_MOD_HEALTH_SHORT"},words={"health"}},
-- 3f4b-rYqbjrGQspuZkY0-0e87fcf7
 {key="mana",label="Mana",api={"ITEM_MOD_MANA_SHORT"},words={"mana"}},
}
F.effects={{key="equip",label="Equip effect"},{key="hit",label="On hit"},{key="proc",label="Triggered / proc"},{key="use",label="On use"},{key="healing",label="Healing text"},{key="damage",label="Damage text"},{key="absorb",label="Absorb / shield text"},{key="resource",label="Resource effect text"}}
local function copy(value)
 if type(value)~="table"then return value end
 local out={};for k,v in pairs(value)do out[k]=copy(v)end;return out
end
F.Copy=copy
local function clean(value)return tostring(value or ""):gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("|H.-|h(.-)|h","%1"):lower():gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","")end
local function contains(text,word)
 local at=1
 while word and word~=""do
  local a,b=text:find(word,at,true);if not a then return false end
  if (a==1 or not text:sub(a-1,a-1):match("[%w_]"))and (b==#text or not text:sub(b+1,b+1):match("[%w_]"))then return true end
  at=b+1
 end
 return false
end
local function selected(t)for _,v in pairs(t or {})do if v then return true end end;return false end
function F:Config()
 L.db.char.wfFilters=type(L.db.char.wfFilters)=="table"and L.db.char.wfFilters or {}
 local c=L.db.char.wfFilters
 for _,k in ipairs({"types","stats","effects"})do if type(c[k])~="table"then c[k]={}end end
 c.statMode=c.statMode=="all"and "all"or "any";c.effectMode=c.effectMode=="all"and "all"or "any"
 c.text=type(c.text)=="string"and c.text:sub(1,150)or ""
 return c
end
function F:Active(c)c=c or self:Config();return selected(c.types)or selected(c.stats)or selected(c.effects)or c.text~=""end
function F:IsWF(d)
 local C=L:GetModule("Constants",true)
-- 7664aaf3.5a7d6c794667456c6e667a.0fd4ffda
 return d and C and d.dt==C.DISCOVERY_TYPE.WORLDFORGED
end
function F:Reset(notify)L.db.char.wfFilters=nil;self.revision=self.revision+1;if notify~=false then self:Changed()end end
function F:Changed()
 self.revision=self.revision+1
 local V=L:GetModule("Viewer",true)
 if V and V.InvalidateFilterCache then V:InvalidateFilterCache()end
 if V and V.window and V.window:IsShown()then V.currentPage=1;V:RefreshData()end
 local M=L:GetModule("Map",true)
 if M then M.cacheIsDirty=true;if M.Update then M:Update()end;if M.UpdateMinimap then M:UpdateMinimap()end end
 if self.SyncPanel then self:SyncPanel(false)end
end
function F:TypeKey(d)
 local _,_,_,_,_,kind,sub,_,slot=GetItemInfo(d.il or d.i)
 if accessorySlots[slot]then return "slot:"..slot end
 local C=L:GetModule("Constants",true)
 local it=(C and C.ITEM_TYPE_TO_ID and C.ITEM_TYPE_TO_ID[kind])or tonumber(d.it)
 local ist=(C and C.ITEM_SUBTYPE_TO_ID and C.ITEM_SUBTYPE_TO_ID[sub])or tonumber(d.ist)
 if it and it>0 and ist and ist>0 then return it..":"..ist end
end
local function group(wanted,actual,mode)
 if not selected(wanted)then return true end
 if mode=="all"then for k,v in pairs(wanted)do if v and not actual[k]then return false end end;return true end
 for k,v in pairs(wanted)do if v and actual[k]then return true end end;return false
end
function F:Parse(lines,api)
 local out={stats={},effects={},text=clean(table.concat(lines," "))}
 for _,s in ipairs(self.stats)do for _,k in ipairs(s.api)do if (tonumber(api[k])or 0)>0 then out.stats[s.key]=true end end end
 local function starts(line,label,fallback)
  label=clean(_G[label]or fallback):gsub("%%s","")
  return label~=""and line:sub(1,#label)==label
-- 72c953:f2d5c4d1eecfedc4c6ced2:2c0e8f98
 end
 for i,line in ipairs(lines)do
  line=clean(line)
  if i>1 then
   local equip=starts(line,"ITEM_SPELL_TRIGGER_ONEQUIP","Equip:")
   local use=starts(line,"ITEM_SPELL_TRIGGER_ONUSE","Use:")
   local hit=starts(line,"ITEM_SPELL_TRIGGER_ONPROC","Chance on hit:")or contains(line,"on hit")
   local passiveChance=line:find("increases?.-chance")or line:find("improves?.-chance")
   local trigger=(contains(line,"chance")and not passiveChance)or contains(line,"when struck")or contains(line,"whenever")or contains(line,"when you")or contains(line,"upon")
   local effect=equip or use or hit or trigger
   if equip then out.effects.equip=true end;if use then out.effects.use=true end
   if hit then out.effects.hit=true end
   if hit or trigger then out.effects.proc=true end
   if effect then
    if contains(line,"heals")or contains(line,"healing")or contains(line,"heal")then out.effects.healing=true end
    if contains(line,"damage")then out.effects.damage=true end
    if contains(line,"absorb")or contains(line,"absorbs")or contains(line,"shield")then out.effects.absorb=true end
    if contains(line,"mana")or contains(line,"rage")or contains(line,"energy")or contains(line,"runic power")then out.effects.resource=true end
   end
   if (line:match("^%+")or effect)and line:match("%d")then
    for _,s in ipairs(self.stats)do
     if (s.key~="health"and s.key~="mana")or line:match("^%+")then
     for _,word in ipairs(s.words)do if contains(line,word)then out.stats[s.key]=true end end
     for _,k in ipairs(s.api)do local label=_G[k];if label and contains(line,clean(label))then out.stats[s.key]=true end end
     end
    end
   end
  end
 end
 return out
end
-- a911-MxQFEC8OLAUHDxM-4045be66
function F:Request(d,key)
 if self.queued[key]or (self.retry[key]and GetTime()<self.retry[key])then return end
 self.queued[key]=true;self.queue[#self.queue+1]={key=key,id=d.i,link=d.il or d.i};if self.worker then self.worker:Show()end
end
function F:Pass(d,row)
 if not self:IsWF(d)then return true end
 local c=self:Config();if not self:Active(c)then return true end
 if selected(c.types)then
  local kind=self:TypeKey(d)
  if not kind then
   local key=tostring(d.il or d.i or "")
   if not self.cache[key]then self:Request(d,key)end
   if not c.includeUnknown then return false end
  elseif not c.types[kind]then return false end
 end
 if not selected(c.stats)and not selected(c.effects)and c.text==""then return true end
 local key=tostring(d.il or d.i or "");local data=self.cache[key]
 if not data then self:Request(d,key);return c.includeUnknown==true end
 return group(c.stats,data.stats,c.statMode)and group(c.effects,data.effects,c.effectMode)and (c.text==""or data.text:find(clean(c.text),1,true)~=nil)
end
function F:Process()
 local changed=false
 for n=1,4 do
  local job=self.queue[self.head];if not job then break end
  self.queue[self.head]=false;self.head=self.head+1;self.queued[job.key]=nil
  local name=GetItemInfo(job.link)
  if name then
   self.tip:SetOwner(UIParent,"ANCHOR_NONE");self.tip:ClearLines();local tooltipOK=pcall(self.tip.SetHyperlink,self.tip,job.link)
   local lines={}
   for i=1,(tooltipOK and self.tip:NumLines()or 0)do
-- 6dd97fda.301706132c0d2f06040c10.fcbeca02
    local left=_G[self.tip:GetName().."TextLeft"..i];local right=_G[self.tip:GetName().."TextRight"..i]
    lines[i]=(left and left:GetText()or "").." "..(right and right:GetText()or "")
   end
   self.tip:Hide()
   if #lines>1 then
    local ok,stats=pcall(GetItemStats,job.link);self.cache[job.key]=self:Parse(lines,ok and type(stats)=="table"and stats or {});changed=true
   else self.retry[job.key]=GetTime()+5 end
  else
   self.retry[job.key]=GetTime()+5
   local C=L:GetModule("Core",true);if C and C.QueueItemForCaching and job.id then C:QueueItemForCaching(job.id)end
  end
 end
 if not self.queue[self.head]then self.queue={};self.head=1;self.worker:Hide()end
 if changed then self.pendingRefresh=true end
end
function F:OnItemInfo()
 if not self:Active()then return end
 self.retry={};self.pendingRefresh=true;if self.refreshFrame then self.refreshFrame:Show()end
end
function F:OnEnable()
 self:Config()
 self.tip=CreateFrame("GameTooltip","LootCollectorWFFilterScan",UIParent,"GameTooltipTemplate");self.tip:Hide()
 self.worker=CreateFrame("Frame");self.worker:Hide();local elapsed=0
 self.worker:SetScript("OnUpdate",function(_,dt)elapsed=elapsed+dt;if elapsed>=.03 then elapsed=0;F:Process();F.refreshFrame:Show()end end)
 self.refreshFrame=CreateFrame("Frame");self.refreshFrame:Hide();local refresh=0
 self.refreshFrame:SetScript("OnUpdate",function(_,dt)refresh=refresh+dt;if refresh>=.4 then refresh=0;F.refreshFrame:Hide();if F.pendingRefresh then F.pendingRefresh=nil;F:Changed()end end end)
 self:RegisterEvent("GET_ITEM_INFO_RECEIVED","OnItemInfo")
end
function F:OnDisable()
 if self.worker then self.worker:Hide()end;if self.refreshFrame then self.refreshFrame:Hide()end;self:UnregisterAllEvents()
end
