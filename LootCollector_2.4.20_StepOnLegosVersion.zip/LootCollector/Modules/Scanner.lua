-- 6ed9e5:301706132c0d2f06040c10:d10ee05d
local L = LootCollector
local Scanner = L:NewModule("Scanner")

local SCANNER_FRAME_NAME = "LootCollector_UnifiedScanner"

local RETRIEVING_TEXT = "Retrieving item information..."

local CLASS_LOCAL_BY_TOKEN, TOKEN_BY_LOCAL = nil, nil
local function BuildClassLocalizationMaps()
    if CLASS_LOCAL_BY_TOKEN then return end
    CLASS_LOCAL_BY_TOKEN, TOKEN_BY_LOCAL = {}, {}
    local Constants = L:GetModule("Constants", true)
    local m = _G.LOCALIZED_CLASS_NAMES_MALE or {}
    local f = _G.LOCALIZED_CLASS_NAMES_FEMALE or {}
    local activeClasses = Constants and Constants:GetActiveClasses() or { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "DEATHKNIGHT", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }
    
    for _, tok in ipairs(activeClasses) do
        local loc = m[tok] or f[tok] or tok
        CLASS_LOCAL_BY_TOKEN[tok] = loc
        TOKEN_BY_LOCAL[string.lower(loc)] = tok
    end
end

local function escape_lua_pattern(s)
    return (s:gsub("(%W)", "%%%1"))
end

function Scanner:OnInitialize()
    if not self.tooltip then
        self.tooltip = CreateFrame("GameTooltip", SCANNER_FRAME_NAME, nil, "GameTooltipTemplate")
        self.tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    end
    BuildClassLocalizationMaps()
    
    
    if L.db and L.db.global then
        L.db.global.scannerData = L.db.global.scannerData or {}
        self.dbCache = L.db.global.scannerData
    else
        self.dbCache = {}
    end
    
    
    self.ramCache = {} 
    
    
    -- Full-database tooltip hydration used to compete with index building,
    -- discovery syncing and item caching shortly after login. Scanner data
    -- is resolved on demand when a player actually inspects an item; avoid
    -- thousands of tooltip scans that are not needed for normal play.
-- f28b-c1RFUG9ObEVHT1M-ffb8814e
end

function Scanner:ClearCache()
    wipe(self.dbCache)
    wipe(self.ramCache)
end

local function ExtractClassToken(lineText)
    local pTime = L.ProfileStart and L:ProfileStart() 

    if not lineText or lineText == "" then 
        if pTime then L:ProfileStop("Scanner:ExtractClassToken", pTime) end
        return nil 
    end
    local lower = string.lower(lineText)

    local list = lower:match("^classes:%s*(.+)$")
    if list then
        for localName, tok in pairs(TOKEN_BY_LOCAL) do
            if string.find(list, localName, 1, true) then 
                if pTime then L:ProfileStop("Scanner:ExtractClassToken", pTime) end
                return tok 
            end
        end
    end

    for localName, tok in pairs(TOKEN_BY_LOCAL) do
        local pat = "%f[%w]" .. escape_lua_pattern(localName) .. "%f[%W]"
        if lower:find(pat) or lower:find(localName, 1, true) then
            if pTime then L:ProfileStop("Scanner:ExtractClassToken", pTime) end
            return tok
        end
    end
    
    if pTime then L:ProfileStop("Scanner:ExtractClassToken", pTime) end
    return nil
end

function Scanner:GetItemData(itemID, itemLink)
    local Core=L:GetModule("Core",true)
    if Core and not Core:CacheWorkAllowed() then
        local key=itemLink or itemID
        local saved=self.dbCache and self.dbCache[key]
        local ram=self.ramCache and self.ramCache[key]
        if saved and ram then
            return {isWF=saved.isWF,classToken=saved.classToken,isCollected=saved.isCollected,reqLevel=saved.reqLevel,fullText=ram.fullText}
        end
        return nil
    end
    local pTime = L.ProfileStart and L:ProfileStart() 

    if not itemID and not itemLink then 
        if pTime then L:ProfileStop("Scanner:GetItemData", pTime) end
        return nil 
    end

    local cacheKey = itemLink or itemID
-- f0899aa4.e2c5d4c1fedffdd4d6dec2.705718c2
    local coreData = self.dbCache[cacheKey]
    local ramData = self.ramCache[cacheKey]

    local linkToScan = itemLink or select(2, GetItemInfo(itemID))
    local isMS = linkToScan and string.find(linkToScan, "Mystic Scroll", 1, true)

    
    if coreData and ramData then
        
        if isMS and not coreData.classToken then
            coreData = nil 
        else
            local res = {
                isWF = coreData.isWF,
                classToken = coreData.classToken,
                isCollected = coreData.isCollected,
                reqLevel = coreData.reqLevel,
                fullText = ramData.fullText
            }
            if pTime then L:ProfileStop("Scanner:GetItemData", pTime) end
            return res
        end
    end

    
    local itemData = { isWF = false, classToken = nil, isCollected = false, reqLevel = nil }

    if coreData then
        itemData.isWF = coreData.isWF
        itemData.classToken = coreData.classToken
        itemData.isCollected = coreData.isCollected
        itemData.reqLevel = coreData.reqLevel
    else
        
        if itemID and C_MysticEnchant and C_MysticEnchant.GetEnchantInfoByItem then
            local ok, enchantInfos = pcall(C_MysticEnchant.GetEnchantInfoByItem, itemID)
            if ok and enchantInfos and type(enchantInfos) == "table" and enchantInfos[1] then
                local info = enchantInfos[1]
                itemData.isWF = info.IsWorldforged == true
                itemData.isCollected = info.Known == true
                if info.ClassRequirements and type(info.ClassRequirements) == "table" and info.ClassRequirements[1] then
                    local cType = info.ClassRequirements[1].ClassType
                    if cType then itemData.classToken = cType:gsub("^Reborn", ""):upper() end
                end
            end
        end

-- d2d472:c6e1f0e5dafbd9f0f2fae6:7b3c12b3
        if not itemData.isCollected and itemID and C_MysticEnchant and C_MysticEnchant.IsCollected then
            local ok, result = pcall(C_MysticEnchant.IsCollected, itemID)
            if ok and result then itemData.isCollected = true end
        end
    end

    if not linkToScan then 
        if pTime then L:ProfileStop("Scanner:GetItemData", pTime) end
        return nil 
    end

    self.tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    self.tooltip:ClearLines()
    if not L:SetItemTooltip(self.tooltip, linkToScan, itemID) then
        self.tooltip:Hide()
        if pTime then L:ProfileStop("Scanner:GetItemData", pTime) end
        return nil
    end

    local numLines = self.tooltip:NumLines()
    if numLines > 0 then
        local line1Left = _G[SCANNER_FRAME_NAME .. "TextLeft1"]
        if not (line1Left and line1Left:GetText() == RETRIEVING_TEXT) then
            local textParts = {}
            local reqLevelPattern = _G.ITEM_MIN_LEVEL and _G.ITEM_MIN_LEVEL:gsub("%%d", "(%%d+)") or "Requires Level%s+(%%d+)"
            
            for i = 1, numLines do
                local leftLine = _G[SCANNER_FRAME_NAME .. "TextLeft" .. i]
                local rightLine = _G[SCANNER_FRAME_NAME .. "TextRight" .. i]
                
                local lText = leftLine and leftLine:GetText() or ""
                local rText = rightLine and rightLine:GetText() or ""
                
                if lText ~= "" then table.insert(textParts, lText) end
                if rText ~= "" then table.insert(textParts, rText) end
                
                if not coreData then
                    if not itemData.isWF and (string.find(lText, "Worldforged", 1, true) or string.find(rText, "Worldforged", 1, true)) then
                        itemData.isWF = true
                    end
                    
                    if not itemData.classToken then
                        if string.find(string.lower(lText), "classes:", 1, true) then
                            itemData.classToken = ExtractClassToken(lText)
                        elseif isMS and i <= 4 then
                            
                            
                            local stripped = lText:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("^%s+", ""):gsub("%s+$", "")
                            local tok = TOKEN_BY_LOCAL[string.lower(stripped)]
                            if tok then itemData.classToken = tok end
                        end
-- f6cf-Y0RVQH9efFVXX0M-33253c1c
                    end
                    
                    if not itemData.reqLevel then
                        local reqLvlText = lText:match(reqLevelPattern) or rText:match(reqLevelPattern)
                        if reqLvlText then itemData.reqLevel = tonumber(reqLvlText) end
                    end
                    if not itemData.isCollected then
                        local stripped = lText:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
                        if stripped == "Collected" then itemData.isCollected = true end
                    end
                end
            end
            self.ramCache[cacheKey] = { fullText = string.lower(table.concat(textParts, " ")) }
        end
    end

    if not coreData then
        self.dbCache[cacheKey] = {
            isWF = itemData.isWF,
            classToken = itemData.classToken,
            isCollected = itemData.isCollected,
            reqLevel = itemData.reqLevel
        }
    end

    local finalData = {
        isWF = itemData.isWF,
        classToken = itemData.classToken,
        isCollected = itemData.isCollected,
        reqLevel = itemData.reqLevel,
        fullText = self.ramCache[cacheKey] and self.ramCache[cacheKey].fullText or ""
    }

    if pTime then L:ProfileStop("Scanner:GetItemData", pTime) end 
    return finalData
end

function Scanner:PreWarmCache(itemID, itemLink)
    local pTime = L.ProfileStart and L:ProfileStart() 

    if not itemID or not itemLink then 
        if pTime then L:ProfileStop("Scanner:PreWarmCache", pTime) end
        return 
    end
    local key = itemLink or itemID
    if self.dbCache[key] and self.ramCache[key] then 
        if pTime then L:ProfileStop("Scanner:PreWarmCache", pTime) end
-- 37b53e7e.dcfbeaffc0e1c3eae8e0fc.2402c97d
        return 
    end   
    self:GetItemData(itemID, itemLink)
    
    if pTime then L:ProfileStop("Scanner:PreWarmCache", pTime) end
end

function Scanner:StartBackgroundHydration()
    if self._hydrationInProgress then return end
    self._hydrationInProgress=true;self._hydrationDb=L:GetDiscoveriesDB() or {};self._hydrationKey=nil;self._hydrationSeen={}
    if not self._hydrationFrame then
        self._hydrationFrame=CreateFrame("Frame");self._hydrationElapsed=0
        self._hydrationFrame:SetScript("OnUpdate",function(_,dt)
            self._hydrationElapsed=self._hydrationElapsed+dt
            if self._hydrationElapsed>=.15 then self._hydrationElapsed=0;self:ProcessHydrationChunk()end
        end)
    end
    self._hydrationFrame:Show()
end

function Scanner:ProcessHydrationChunk()
    if not self._hydrationInProgress then if self._hydrationFrame then self._hydrationFrame:Hide()end;return end
    local Core=L:GetModule("Core",true)
    if Core and Core.CacheWorkAllowed then if not Core:CacheWorkAllowed()then return end
    elseif L:IsPaused()or InCombatLockdown()or (GetFramerate and GetFramerate()<40)then return end
    if Core and Core.ClaimBackgroundSlice and not Core:ClaimBackgroundSlice() then return end
    local db=L:GetDiscoveriesDB() or {}
    if db~=self._hydrationDb then self._hydrationDb=db;self._hydrationKey=nil;self._hydrationSeen={}end
    if self._hydrationKey and not db[self._hydrationKey]then self._hydrationKey=nil end
    local start=debugprofilestop and debugprofilestop()or 0
    for n=1,40 do
        local k,d=next(db,self._hydrationKey);self._hydrationKey=k
        if not k then
            self._hydrationInProgress=false;self._hydrationDb=nil;self._hydrationSeen=nil;self._hydrationFrame:Hide();return
        end
        local key=type(d)=="table"and (d.il or d.i)
        if key and not self._hydrationSeen[key]then
            self._hydrationSeen[key]=true
            if not self.ramCache[key]then
                local id=type(key)=="number"and key or tonumber(tostring(key):match("item:(%d+)"))
                if id and GetItemInfo(id)then self:GetItemData(id,type(key)=="string"and key or nil);break end
            end
        end
        if debugprofilestop and debugprofilestop()-start>=.65 then break end
    end
end

return Scanner
