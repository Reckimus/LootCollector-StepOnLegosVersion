local L = LootCollector
local Starter = L:NewModule("StarterLocations")
local PACK = "LootCollector_CRSeed"
local REALM = "Conquest Reborn"
local REVISION = 1

function Starter:IsAvailable()
    return L:GetActiveRealmKey() == REALM and GetAddOnInfo and GetAddOnInfo(PACK) ~= nil
end

function Starter:OnEnable()
    if not self:IsAvailable() then return end
    local bucket = L.db.global.realms[REALM]
    if not bucket or (bucket.starterLocationsRevision or 0) >= REVISION then return end

    local frame = CreateFrame("Frame")
    local elapsed = 0
    frame:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + dt
        if elapsed < .10 then return end
        elapsed = 0
        local core = L:GetModule("Core", true)
        if not core or not core._enteredWorldOnce or L:IsPaused() then return end
        if (InCombatLockdown and InCombatLockdown()) or (GetFramerate and GetFramerate() < 40) then return end
        local mapOpen = WorldMapFrame and WorldMapFrame:IsShown()
        if mapOpen then
            if not core:ClaimWorldMapSlice() then return end
        elseif not core:ClaimBackgroundSlice("starter locations") then
            return
        end

        if not self.sections then
            local loaded = LoadAddOn(PACK)
            local data = _G.LootCollector_CRSeedData
            _G.LootCollector_CRSeedData = nil
            if not loaded or not data then frame:Hide(); return end
            local poi = L:GetModule("POI", true)
            self.sections = {
                { rows = data.discoveries, db = L:GetDiscoveriesDB() },
                { rows = data.blackmarketVendors, db = L:GetVendorsDB() },
                { rows = data.pointsOfInterest, db = poi:GetDB(), poi = poi },
            }
            self.section = 1
            self:ResetSection()
        end

        local start = debugprofilestop and debugprofilestop()
        local changed = false
        for step = 1, 96 do
            local section = self.sections[self.section]
            if not section then
                bucket.starterLocationsRevision = REVISION
                self.sections = nil
                frame:Hide()
                break
            end
            if not self:StepSection(section, core) then break end
            changed = changed or self.inserted
            if start and debugprofilestop() - start >= .65 then break end
        end
        if changed then
            L.DataHasChanged = true
            local map = L:GetModule("Map", true)
            if map then map.cacheIsDirty = true end
        end
    end)
end

function Starter:ResetSection()
    self.count, self.cursor, self.position = 0, nil, nil
end

function Starter:StepSection(section, core)
    self.inserted = false
    if not self.position then
        -- Stop counting as soon as this section is already as large as the pack.
        if self.cursor and section.db[self.cursor] == nil then
            self.cursor, self.count = nil, 0
        end
        local key = next(section.db, self.cursor)
        if not key then
            self.position = 1
        else
            self.cursor = key
            self.count = self.count + 1
            if self.count >= #section.rows then
                self.section = self.section + 1
                self:ResetSection()
            end
        end
        return true
    end

    local row = section.rows[self.position]
    if not row then
        self.section = self.section + 1
        self:ResetSection()
        return true
    end
    local key, record = row[1], row[2]
    if not section.db[key] then
        if section.poi then
            if not section.poi:EnsureIndex(section.db) then return false end
            if not section.poi:FindNear(record) then
                self.inserted = section.poi:Store(record, false) ~= nil
            end
        else
            section.db[key] = record
            core:AddToZoneIndex(key, record.z)
            if L.SendMessage then L:SendMessage("LootCollector_DiscoveriesUpdated", "add", key, record) end
            self.inserted = true
        end
    end
    self.position = self.position + 1
    return true
end
