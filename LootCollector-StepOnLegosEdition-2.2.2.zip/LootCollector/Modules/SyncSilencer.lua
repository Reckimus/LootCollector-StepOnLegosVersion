-- Targeted addon-whisper error silencer. Addition by StepOnLegos, 2.2.2.
-- No global error hiding: only recent LC protocol recipients are eligible.
local L=LootCollector
local S=L:NewModule("SyncSilencer","AceEvent-3.0")
local WINDOW,MANUAL_WINDOW=30,15
S.pending,S.manual={},{}
S.hidden=0
local prefixes={BBLC25AM=true,LC1=true,LCDB1=true,LCPOI1=true,LCR1=true}
local function key(name)
    if type(name)~="string"then return end
    name=name:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):match("^%s*(.-)%s*$")
    if name==""then return end
    return name:lower()
end
local function short(name)return name and name:match("^[^-]+")end
local function escape(text)return (text:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])","%%%1"))end
local function pattern(template)
    if type(template)~="string"then return end
    local first,last=template:find("%%s")
    if not first then first,last=template:find("%%1%$s")end
    if not first then return end
    return "^"..escape(template:sub(1,first-1)).."(.-)"..escape(template:sub(last+1)).."$"
end
function S:Enabled()return self.active and L.db and L.db.profile.syncErrorSilencer~=false end
function S:Record(table_,target)
    local name=key(target);if not name then return end
    local now=GetTime();table_[name]=now;table_[short(name)]=now
    if not self.nextPrune or now>=self.nextPrune then
        self.nextPrune=now+5
        for _,t in ipairs({self.pending,self.manual})do for n,at in pairs(t)do if now-at>WINDOW then t[n]=nil end end end
    end
end
function S:Outgoing(prefix,_,distribution,target)
    if not self.active or distribution~="WHISPER"then return end
    if not prefixes[prefix]and prefix~=L.addonPrefix then return end
    self:Record(self.pending,target)
end
function S:ManualWhisper(_,distribution,_,target)
    if self.active and distribution=="WHISPER"then self:Record(self.manual,target)end
end
function S:Filter(_,event,message)
    if event~="CHAT_MSG_SYSTEM"or not self:Enabled()or type(message)~="string"then return false end
    local text=message:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
    local name=self.errorPattern and text:match(self.errorPattern)
    if not name then return false end
    local n=key(name);if not n then return false end
    local now=GetTime();local recent=self.pending[n]or self.pending[short(n)]
    if not recent or now-recent>WINDOW then return false end
    -- Never silence the result of a user's recent normal whisper, even to an LC peer.
    local manual=self.manual[n]or self.manual[short(n)]
    if manual and now-manual<=MANUAL_WINDOW then return false end
    -- A filter is invoked once for each chat frame. Count one match per tick/text.
    if self.lastMessage~=message or self.lastMatchAt~=now then self.hidden=self.hidden+1 end
    self.lastMessage,self.lastMatchAt,self.lastName=message,now,name
    return true
end
function S:Command(value)
    local cmd=(value or ""):match("^%s*(.-)%s*$"):lower()
    if cmd=="on"or cmd=="off"then L.db.profile.syncErrorSilencer=cmd=="on"end
    local state=L.db.profile.syncErrorSilencer~=false and "on"or "off"
    DEFAULT_CHAT_FRAME:AddMessage("|cff80cfffLootCollector:|r Sync error silencer "..state..". Matched this session: "..self.hidden..(self.lastName and ("; last: "..self.lastName)or "")..". /lcsilence on | off | status")
end
function S:OnEnable()
    self.active=true
    if L.db.profile.syncErrorSilencer==nil then L.db.profile.syncErrorSilencer=true end
    self.errorPattern=pattern(ERR_CHAT_PLAYER_NOT_FOUND_S or "No player named '%s' is currently playing.")
    if not self.hooked then
        self.hooked=true
        hooksecurefunc("SendAddonMessage",function(...)S:Outgoing(...)end)
        hooksecurefunc("SendChatMessage",function(...)S:ManualWhisper(...)end)
    end
    self.filter=self.filter or function(...)return S:Filter(...)end
    ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM",self.filter)
    SLASH_LCSYNCERRORSILENCER1="/lcsilence"
    SlashCmdList.LCSYNCERRORSILENCER=function(value)S:Command(value)end
end
function S:OnDisable()
    self.active=false
    if self.filter then ChatFrame_RemoveMessageEventFilter("CHAT_MSG_SYSTEM",self.filter)end
end
