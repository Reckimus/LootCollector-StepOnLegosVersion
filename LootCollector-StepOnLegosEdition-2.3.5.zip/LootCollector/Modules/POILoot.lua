-- 64c2b3:e7c0d1c4fbdaf8d1d3dbc7:6fefaef6
-- Latest observed loot window for each chest/rare location. Not a drop table.
local L=LootCollector
local P=L:GetModule("POI")
local M=L:NewModule("POILoot","AceEvent-3.0")
local MAX_ITEMS=32
local function int(n,lo,hi)return type(n)=="number" and n==math.floor(n) and n>=lo and n<=hi end
local function enabled()
    local cfg=L.db and L.db.profile and L.db.profile.poi
    return cfg and cfg.enabled~=false and not L:IsPaused() and not L:IsZoneIgnored()
end
local function person(s)
    if type(s)=="string" and #s>0 and #s<=64 and not s:find("[|%c]") then return s end
end
function M:ValidateReport(r)
    if type(r)~="table" or not int(r.at,946684800,time()+300) or type(r.items)~="table" or #r.items>MAX_ITEMS then return end
    local out={at=r.at,by=person(r.by),items={},partial=r.partial==true}
    for i=1,#r.items do
        local v=r.items[i]
        if type(v)~="table" or not int(v.id,1,16777215) or not int(v.q,1,100000) then return end
        local link
        if type(v.link)=="string" and #v.link<=120 and v.link:match("^item:[%d:%-]+$")
            and tonumber(v.link:match("^item:(%d+)"))==v.id then link=v.link end
        out.items[i]={id=v.id,q=v.q,link=link}
    end
    return out
end
function M:ReportKey(r)
    if not r then return "" end
    local t={tostring(r.at),r.partial and "p" or "f"}
    for _,v in ipairs(r.items)do t[#t+1]=(v.link or tostring(v.id)).."x"..v.q end
    return table.concat(t,";")
end
function M:IsNewer(a,b)
    if not a then return false end
    if not b then return true end
    if a.at~=b.at then return a.at>b.at end
    -- Stable convergence for reports taken in the same second; an incomplete
    -- view cannot replace a complete view of the same opening.
    if a.partial~=b.partial then return not a.partial end
    return self:ReportKey(a)>self:ReportKey(b)
end
function M:WireReport(r,anonymous)
    local out=self:ValidateReport(r)
    if out and anonymous then out.by=nil end
    return out
end
function M:RememberUnit(unit)
    if not enabled() or L.db.profile.poi.trackRares==false or not UnitExists(unit) or UnitIsPlayer(unit) then return end
    local class=UnitClassification(unit)
    if class~="rare" and class~="rareelite" then return end
    local guid=UnitGUID(unit)
    local c,z,fl,x,y=P:GetLocation()
-- 10a0-zun47dLz0fj68u4-182ce301
    if guid and c then
        self.rareCandidate={guid=guid,n=UnitName(unit),c=c,z=z,fl=fl,x=x,y=y,
            elite=class=="rareelite",level=UnitLevel(unit),t=GetTime()}
    end
end
function M:ResolveSource()
    if not enabled() or (IsFishingLoot and IsFishingLoot()) then return end
    -- A recent world-object hover identifies chests; never use a nearby pin
    -- or an unrelated selected dead target as a loot source.
    local chest=P.chestCandidate
    if chest and GetTime()-chest.t<=1.5 and not UnitExists("mouseover") then
        local d,key=P:ObserveChest(chest.n,true)
        if d then return d,key end
    end
    self:RememberUnit("mouseover")
    local r=self.rareCandidate
    if not r or GetTime()-r.t>2 then return end
    local match=false
    for _,unit in ipairs({"mouseover","target"})do
        if UnitExists(unit) and UnitGUID(unit)==r.guid and UnitIsDead(unit)
            and CheckInteractDistance and CheckInteractDistance(unit,3) then
            -- Target-only selection is not proof on 3.3.5. Require the corpse
            -- under the cursor, or the optional client loot-source API.
            if unit=="mouseover" then match=true end
        end
    end
    if not match and GetLootSourceInfo and GetNumLootItems then
        for i=1,GetNumLootItems()do
            local sources={GetLootSourceInfo(i)}
            for j=1,#sources,2 do if sources[j]==r.guid then match=true end end
        end
    end
    if not match then return end
    local c,z,fl,x,y=P:GetLocation()
    if not c or c~=r.c or z~=r.z or fl~=r.fl then return end
    return P:Store({k="RARE",n=r.n,id=tonumber(r.guid:sub(7,12),16) or tonumber(r.guid:match("Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")) or 0,
        c=c,z=z,fl=fl,x=x,y=y,ls=time(),t0=time(),elite=r.elite,level=r.level,close=true},true,nil,r.guid)
end
function M:OnLootOpened()
    -- Reopening an unlooted source creates another observed-window report.
    self:OnLootClosed()
    local d,key=self:ResolveSource()
    P.chestCandidate=nil
    if not d then return end
    self.session={key=key,db=P:GetDB(),at=time(),slots={},partial=false}
    self:Capture()
end
function M:Capture()
    local s=self.session
    if not s or s.frozen or not enabled() or s.db~=P:GetDB() then return end
    local count=GetNumLootItems and GetNumLootItems() or 0
    for i=1,math.min(count,100)do
-- 4a8e8256.ad8a9b8eb190b29b99918d.866764ac
        if s.slots[i]~=false then
            local link=GetLootSlotLink and GetLootSlotLink(i)
            local itemstring=link and link:match("(item:[%d:%-]+)")
            local id=itemstring and tonumber(itemstring:match("item:(%d+)"))
            if id then
                local _,_,q=GetLootSlotInfo(i)
                s.slots[i]={id=id,q=tonumber(q) or 1,link=#itemstring<=120 and itemstring or nil}
            elseif not s.slots[i] and (not LootSlotIsItem or LootSlotIsItem(i)) then
                s.unresolved=s.unresolved or {};s.unresolved[i]=true
            end
            if id and s.unresolved then s.unresolved[i]=nil end
        end
    end
    -- Save immediately: auto-loot can close before another frame update.
    self:Commit()
end
function M:Commit()
    local s=self.session
    if not s or not enabled() or s.db~=P:GetDB() then return end
    local d=s.db[s.key];if not d then return end
    local items,byID={},{}
    for i=1,100 do
        local v=s.slots[i]
        if type(v)=="table" then
            local k=v.link or tostring(v.id)
            if byID[k] then byID[k].q=math.min(100000,byID[k].q+v.q)
            elseif #items<MAX_ITEMS then
                local copy={id=v.id,q=v.q,link=v.link};items[#items+1]=copy;byID[k]=copy
            else s.partial=true end
        end
    end
    table.sort(items,function(a,b)return (a.link or tostring(a.id))<(b.link or tostring(b.id)) end)
    local r=self:ValidateReport({at=s.at,by=UnitName("player"),items=items,partial=s.partial or (s.unresolved and next(s.unresolved)~=nil)})
    if not r or (d.loot and self:ReportKey(d.loot)==self:ReportKey(r)) then return end
    if d.loot and d.loot.at>r.at then return end
    d.loot=r
    P:Changed()
    local cfg=L.db.profile
    if cfg.sharing.enabled and cfg.poi.share~=false then
        P.pending[s.key]=time()+(cfg.sharing.delayed and (tonumber(cfg.sharing.delaySeconds) or 30) or 0)
    end
end
function M:OnLootClosed()
    if self.session then self:Commit();self.session=nil end
end
function M:Hide()
    if self.frame then self.frame:Hide() end
    if self.itemTip then self.itemTip:Hide() end
    self.pin=nil
end
function M:CreatePanel()
    if self.frame then return end
    local f=CreateFrame("Frame","LootCollectorPOILootPanel",UIParent)
-- 13ac12:0e29382d123311383a322e:b137c5b3
    self.frame=f;self.rows={}
    f:SetWidth(300);f:EnableMouse(true);f:SetClampedToScreen(true)
    f:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=16,insets={left=4,right=4,top=4,bottom=4}})
    f:SetBackdropColor(.08,.08,.08,.96)
    f.title=f:CreateFontString(nil,"OVERLAY","GameFontNormal");f.title:SetPoint("TOPLEFT",12,-12);f.title:SetWidth(250);f.title:SetJustifyH("LEFT")
    f.meta=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");f.meta:SetPoint("TOPLEFT",12,-34);f.meta:SetWidth(270);f.meta:SetJustifyH("LEFT")
    f.note=f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall");f.note:SetPoint("BOTTOMLEFT",12,12);f.note:SetWidth(270);f.note:SetJustifyH("LEFT")
    local close=CreateFrame("Button",nil,f,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-2,-2)
    close:SetScript("OnClick",function()M.dismissed=M.pin;M:Hide()end)
    f.scroll=CreateFrame("ScrollFrame","LootCollectorPOILootScroll",f,"UIPanelScrollFrameTemplate")
    f.scroll:SetPoint("TOPLEFT",12,-70);f.scroll:SetPoint("BOTTOMRIGHT",-32,43)
    f.content=CreateFrame("Frame",nil,f.scroll);f.content:SetWidth(256);f.content:SetHeight(1);f.scroll:SetScrollChild(f.content)
    self.itemTip=CreateFrame("GameTooltip","LootCollectorPOIItemTooltip",UIParent,"GameTooltipTemplate")
    for i=1,MAX_ITEMS do
        local row=CreateFrame("Button",nil,f.content);self.rows[i]=row
        row:SetSize(252,24);row:SetPoint("TOPLEFT",0,-(i-1)*24);row:EnableMouse(true)
        row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight","ADD")
        row.icon=row:CreateTexture(nil,"ARTWORK");row.icon:SetSize(20,20);row.icon:SetPoint("LEFT",0,0)
        row.text=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");row.text:SetPoint("LEFT",row.icon,"RIGHT",5,0);row.text:SetWidth(224);row.text:SetJustifyH("LEFT")
        row:SetScript("OnEnter",function(btn)
            if not btn.item then return end
            local tip=M.itemTip;tip:SetParent(f:GetParent());tip:SetScale(f:GetScale());tip:SetFrameStrata("TOOLTIP");tip:SetFrameLevel(f:GetFrameLevel()+20)
            tip:SetOwner(btn,"ANCHOR_LEFT");tip:SetHyperlink(btn.item.link or "item:"..btn.item.id);tip:Show()
        end)
        row:SetScript("OnLeave",function()M.itemTip:Hide()end)
        row:Hide()
    end
    f:Hide()
end
function M:RefreshPanel()
    local pin=self.pin;local d=pin and pin.record;if not d then self:Hide();return end
    local f=self.frame;local r=d.loot
    f.title:SetText(d.n)
    local meta="No reported loot yet"
    if r then
        meta="Last loot: "..date("%m/%d %H:%M",r.at)
        if r.by and not L.db.profile.hidePlayerNames then meta=meta.."\nReported by: "..r.by end
    elseif d.drops then meta="Older report (time unknown)" end
    f.meta:SetText(meta)
    local n=r and #r.items or 0
    f:SetHeight(122+math.min(math.max(n,1),10)*24)
    f.content:SetHeight(math.max(n,1)*24)
    for i,row in ipairs(self.rows)do
        local v=r and r.items[i];row.item=v
        if v then
            local name,link,quality,_,_,_,_,_,_,icon=GetItemInfo(v.link or v.id)
            local color=ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality or 1]
            row.text:SetText((name or ("Item #"..v.id))..(v.q>1 and (" x"..v.q) or ""))
            row.text:SetTextColor(color and color.r or 1,color and color.g or 1,color and color.b or 1)
            row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark");row:Show()
        else row:Hide() end
    end
-- f0fe-EDcmMwwtDyYkLDA-cd068dda
    if r then
        f.note:SetText(r.partial and "Partial loot report; some items unavailable.\nContents vary between spawns." or (n==0 and "No items visible when opened.\nContents vary between spawns." or "Hover an item for details.\nReported contents; future loot may differ."))
    elseif d.drops then f.note:SetText(d.drops)
    else f.note:SetText("Open this chest or loot this rare to report\nits contents. Future loot may differ.") end
end
function M:ShowForPin(pin)
    if not enabled() or self.dismissed==pin then return end
    self:CreatePanel()
    if self.pin~=pin then self.frame.scroll:SetVerticalScroll(0);self.itemTip:Hide();self.dismissed=nil end
    self.pin=pin;self.lastOver=GetTime()
    local parent=WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame or UIParent
    local f=self.frame;f:SetParent(parent);f:SetScale(UIParent:GetEffectiveScale()/parent:GetEffectiveScale())
    f:SetFrameStrata("TOOLTIP");f:SetFrameLevel(math.max(parent:GetFrameLevel(),pin:GetFrameLevel())+80)
    f:ClearAllPoints()
    if parent==WorldMapFrame then f:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-45,-70)
    else f:SetPoint("TOPLEFT",pin,"TOPRIGHT",8,0) end
    local proximity=L:GetModule("ProximityList",true)
    if proximity and proximity:IsShown() then proximity:Hide("POI loot") end
    self:RefreshPanel();f:Show()
end
function M:Tick()
    if self.session then self:Capture() end
    if self.dismissed and MouseIsOver and not MouseIsOver(self.dismissed) then self.dismissed=nil end
    if not self.frame or not self.frame:IsShown() then return end
    local pin=self.pin
    local proximity=L:GetModule("ProximityList",true)
    if not enabled() or not pin or not pin:IsShown() or not pin.record
        or (self.frame:GetParent()==WorldMapFrame and not WorldMapFrame:IsShown())
        or (proximity and proximity:IsShown()) then self:Hide();return end
    local over=MouseIsOver and (MouseIsOver(pin) or MouseIsOver(self.frame))
    if over then self.lastOver=GetTime()
    elseif GetTime()-(self.lastOver or 0)>.65 then self.dismissed=nil;self:Hide();return end
    self:RefreshPanel()
end
function M:OnEnable()
    if L.LEGACY_MODE_ACTIVE then return end
    self:RegisterEvent("UPDATE_MOUSEOVER_UNIT",function()M:RememberUnit("mouseover")end)
    self:RegisterEvent("LOOT_CLOSED","OnLootClosed")
    self:RegisterEvent("LOOT_SLOT_CLEARED",function(_,slot)
        if M.session then
            -- Keep the initial slot snapshot after items disappear.
            M.session.frozen=true
        end
    end)
    self:RegisterEvent("PLAYER_ENTERING_WORLD",function()M.session=nil;M.rareCandidate=nil;M:Hide()end)
    self:RegisterEvent("ZONE_CHANGED_NEW_AREA",function()M.session=nil;M.rareCandidate=nil;M:Hide()end)
    self.driver=CreateFrame("Frame");local elapsed=0
    self.driver:SetScript("OnUpdate",function(_,dt)elapsed=elapsed+dt;if elapsed>=.2 then elapsed=0;M:Tick()end end)
end
function M:OnDisable()
    self.session=nil;self:Hide();if self.driver then self.driver:Hide()end
    self:UnregisterAllEvents()
-- 91bba31f.694e5f4a7554765f5d5549.aa3b62d2
end
